import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        DynArray obj=new DynArray();

       for(int i=1 ;i<6 ; i++)
       {
           obj.insert(i);
       }
       obj.print();
        System.out.println(obj.index);
       obj.deleteElement(2);
       obj.dele(2);



        obj.print();
        System.out.println(obj.index);

    }}
class DynArray{
    public int index; int cap;
    int arr[];
    DynArray() {
        index=0; cap=4;
        arr=new int[cap];
    }
    void insert(int val) {
        if(index<cap) {
            arr[index]=val;
            index++;
        }
        else
        {
            growindex();
            arr[index]=val;
            index++;
        }
    }
    void growindex(){
        cap=cap+cap/2;
        int temp[]=new int[cap];
        for(int i=0;i<index;i++) {
            temp[i]=arr[i];
        }
        arr=temp;
    }

    void print(){
        for(int i=0;i<index;i++) {
            System.out.println("This is your array list : " +arr[i]);
        }
    }

    void del() {
        if(index>0) {index--;
            arr[index]=0;

        }
        else {
            if(index==0) {
                System.out.println("It is first index");
            }
        }}
    void dele(int v) {

        for(int k=v;k<index;k++) {
            arr[k] = arr[k+1];

        }
        index--;
    }
    void deleteElement(int a)
    {
        for(int i=0 ; i<index ; i++)
        {
            if(arr[i] == a)
            {
                arr[i] = 0;
                for(int j = i ; j < index; j++)
                {
                    arr[j] = arr[j+1];
                }
            }

        }
        index--;
    }


    void repla(int a,int b) {
        for(int i =0 ; i<index ; i++)
        {
            if(arr[i] == a)
            {
                arr[i] = b;

            }
        }

    }

    void indexsixesmall() {
        if(index<cap/2) {
            cap=cap/2;
            int temp[]=new int[cap];
            for(int i=0;i<index;i++) {
                temp[i]=arr[i];
            }
            arr=temp;
            temp=null;
        }
    }




}