import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main {
    public static void main(String[] args) {

        JFrame f = new JFrame();
        JToggleButton b = new JToggleButton("ON");
        ActionListener a = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    if(b.isSelected()) {
                        f.getContentPane().setBackground(Color.yellow);


                    }
                    else
                    {
                        f.getContentPane().setBackground(Color.WHITE);
                        b.setText("ON");

                    }

            }
        };

        f.setSize(500,500);
        f.setLocationRelativeTo(null);
        f.setBounds(500,500,500,500);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.WHITE);
        f.add(b);
        Dimension size = b.getPreferredSize();
        b.setBounds(300, 180, size.width, size.height);
        b.addActionListener(a);


    }

}
