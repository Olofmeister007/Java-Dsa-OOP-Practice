public class Main {
    public static void main(String[] args){

        Number n1 = new Number(5);
        System.out.println(n1.isPrime());
        System.out.println(n1.getfactorial());
        System.out.println(n1.getsqrt());
    }
}

class Number {
    double number ;

    public Number(double number) {
        this.number = number;
    }

    boolean isPrime()
    {

        for(int i = 2; i<=number/2;i++)
        {
            if(number % i == 0)
                return false;

        }
       return true;
    }

    double getfactorial()
    {
        double fact = 1;
        for(double i = number; i>= 1; i--)
        {
            fact *= i;
        }
        return fact;
    }

    double getsqrt()
    {
        double root;
        root = Math.sqrt(number);
        return root;
    }


}
