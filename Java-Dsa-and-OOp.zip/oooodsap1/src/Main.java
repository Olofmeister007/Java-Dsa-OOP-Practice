import java.util.Scanner;

class Concert {
    public double a, b, c, total;

    public void Concert() {
        a=0.0;
        b=0.0;
        c=0.0;
    }

    public void setSales(double sa, double sb, double sc) {
        a=sa;
        b=sb;
        c=sc;
    }

    public double getTotalSales() {

        total=(a*3000)+(b*2000)+(c*1000);
        return total;
    }
}

 class P3_2{
    public static void main(String[] args) {
        double  seatA, seatB, seatC;
        Concert tickets;
        tickets= new Concert();
        System.out.println(tickets.a);
        Scanner scn= new Scanner (System.in);
        System.out.println("Enter the number of tickets sold of type A?");
        seatA= scn.nextDouble();
        System.out.println("Enter the number of tickets sold of type B?");
        seatB= scn.nextDouble();
        System.out.println("Enter the number of tickets sold of type C?");
        seatC= scn.nextDouble();


        tickets.setSales(seatA, seatB, seatC);
        System.out.println(tickets.c);

        System.out.println("Total sales of concert: " + tickets.getTotalSales());

    }
}

