public class Main {
    public static void main(String[] args){
        Retard test1 = new Retard("Meow","95");
        System.out.println(test1.name);

    }
}
class Retard {
    String name;
    String age;
    String Gender;

    public Retard(String name, String age, String gender) {
        this.name = name;
        this.age = age;
        this.Gender = gender;
    }
    public Retard(String name, String age) {
        this(name,age,"");
    }

    public Retard() {
        this("Unknown","Unassigned","zero");
    }




}