import java.awt.image.AreaAveragingScaleFilter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        Graph graph = new Graph(5);
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);
        graph.addEdge(3, 4);
        List<Integer> neighbors = graph.getNeighbors(2);

        graph.breadthFirstSearch(0);
        System.out.println();
        graph.depthFirstSearch(0);

    }
}


// Using Adjacency List

class Graph {
    // Number of nodes in the graph
    private int numNodes;

    // Adjacency list representation of the graph
    private List<List<Integer>> adjacencyList;

    public Graph(int numNodes) {
        this.numNodes = numNodes;
        this.adjacencyList = new ArrayList<>(numNodes);

        for (int i = 0; i < numNodes; i++) {
            adjacencyList.add(new ArrayList<>());
        }
    }

    public void addEdge(int u, int v) {
        // Add an edge from node u to node v
        adjacencyList.get(u).add(v);

        // Add an edge from node v to node u
        adjacencyList.get(v).add(u);
    }

    public List<Integer> getNeighbors(int node) {
        // Return the list of neighbors for the given node
        return adjacencyList.get(node);
    }

    public void breadthFirstSearch(int startNode) {
        // Create a queue to store the nodes that need to be visited
        Queue<Integer> queue = new LinkedList<>();

        // Create a list to store the nodes that have been visited
        List<Integer> visited = new ArrayList<>();

        // Add the start node to the queue and the visited list
        queue.offer(startNode);
        visited.add(startNode);

        // While the queue is not empty
        while (!queue.isEmpty()) {
            // Remove the next node from the queue
            int node = queue.poll();

            // Print the node
            System.out.println(node);

            // Get the neighbors of the node
            List<Integer> neighbors = getNeighbors(node);

            // Add the unvisited neighbors to the queue and the visited list
            for (int neighbor : neighbors) {
                if (!visited.contains(neighbor)) {
                    queue.offer(neighbor);
                    visited.add(neighbor);
                }
            }
        }
    }
    public void depthFirstSearch(int startNode) {
        // Create a stack to store the nodes that need to be visited
        Stack<Integer> stack = new Stack<>();

        // Create a list to store the nodes that have been visited
        List<Integer> visited = new ArrayList<>();

        // Add the start node to the stack and the visited list
        stack.push(startNode);
        visited.add(startNode);

        // While the stack is not empty
        while (!stack.isEmpty()) {
            // Get the next node from the top of the stack
            int node = stack.pop();

            // Print the node
            System.out.println(node);

            // Get the neighbors of the node
            List<Integer> neighbors = getNeighbors(node);

            // Add the unvisited neighbors to the stack and the visited list
            for (int neighbor : neighbors) {
                if (!visited.contains(neighbor)) {
                    stack.push(neighbor);
                    visited.add(neighbor);
                }
            }
        }
    }
}



