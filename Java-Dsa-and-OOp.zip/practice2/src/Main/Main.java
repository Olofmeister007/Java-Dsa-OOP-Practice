package Main;
import gul.meow;

public class Main {
    public static void main(String[] args){
        Meow kunal = new Meow()
    }


}