package gul;


public class meow {
    int age;
    String name;
    int salary;
    boolean married;

    public meow(int age, String name, int salary, boolean married) {
        this.age = age;
        this.name = name;
        this.salary = salary;
        this.married = married;
    }
}
