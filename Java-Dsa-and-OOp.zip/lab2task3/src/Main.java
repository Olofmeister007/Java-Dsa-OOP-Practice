import java.util.Scanner;

import java.util.*;
public class Main {
    public static void main (String[] args)
    {
        int number;
        int guess;
        int counter = 1;
        boolean flag = true;

        Scanner input = new Scanner(System.in);


        number = (int)(Math.random()*1001);

        System.out.println(number);

        System.out.println("Enter your guess");
        guess = input.nextInt();

        while (guess != number) {
            if(guess < number) {
                System.out.print("Too low, try again.");
                counter += 1;
                flag = false;
            }
            else {
                System.out.print("Too high, try again.");
                counter += 1;
                flag = false;
            }
            System.out.println();
            System.out.println("Enter your guess.");
            guess = input.nextInt();
        }
        if (flag = true) {
            System.out.println("You have guessed correctly in  " + counter + " attempts");
            System.out.println("The number(to be guessed) was: " + number);
        }
    }

}