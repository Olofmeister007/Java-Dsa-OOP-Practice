public class Main {
    public static void main(String[] args) {

    }
}

class Employee{
    String name;
    int id;
    double salary;
}

class AssistanProfessor extends Employee{

}