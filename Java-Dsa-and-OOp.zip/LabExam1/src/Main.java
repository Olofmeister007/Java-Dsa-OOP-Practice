// ****************************************************************
// ManageAccounts.java
//
// Use Account class to create and manage Sally and Joe's
// bank accounts
// ****************************************************************
public class Main {
    public static void main(String[] args) {
        Account acct1, acct2;
        // create account1 for Sally with $1000
        acct1 = new Account(1000, "Sally", 1111);
        // create account2 for Joe with $500
        acct2 = new Account(500,"Joe",2222);
        // deposit $100 to Joe's account
        acct2.deposit(100);
        // print Joe's new balance (use getBalance())
        System.out.println(acct2.getBalance());
        // withdraw $50 from Sally's account
        acct1.withdraw(50);
        // print Sally's new balance (use getBalance())
        System.out.println(acct1.getBalance());
        // charge fees to both accounts
        acct1.chargeFee();
        acct2.chargeFee();
        // change the name on Joe's account to Joseph
        acct2.changeName("Joseph");
        // print summary for both accounts
        System.out.println(acct1.toString());
        System.out.println(acct1.getBalance());
        System.out.println(acct1.chargeFee());
        acct1.withdraw(20);
        acct1.changeName("haha");
        acct1.deposit(20);
        System.out.println();

        System.out.println(acct2.toString());
        System.out.println(acct2.getBalance());
        System.out.println(acct2.chargeFee());
        acct2.withdraw(20);
        acct2.changeName("haha");
        acct2.deposit(20);

    }
}

//*******************************************************
// Account.java
//
// A bank account class with methods to deposit to, withdraw from,
// change the name on, charge a fee to, and print a summary of the account.
//*******************************************************
 class Account {
    private double balance;
    private String name;
    private long acctNum;

    // ----------------------------------------------
    // Constructor -- initializes balance, owner, and account number
    // ----------------------------------------------
    public Account(double initBal, String owner, long number) {
        balance = initBal;
        name = owner;
        acctNum = number;
    }

    // ----------------------------------------------
    // Checks to see if balance is sufficient for withdrawal.
    // If so, decrements balance by amount; if not, prints message.
    // ----------------------------------------------
    public void withdraw(double amount) {
        if (balance >= amount)
            balance -= amount;
        else
            System.out.println("Insufficient funds");
    }

    // ----------------------------------------------
    // Adds deposit amount to balance.
    // ----------------------------------------------
    public void deposit(double amount) {
        balance += amount;
    }

    // ----------------------------------------------
    // Returns balance.
    // ----------------------------------------------
    public double getBalance() {
        return balance;
    }

    // ----------------------------------------------
    // Returns a string containing the name, account number, and balance.
    // ----------------------------------------------
    public String toString() {
        String xd;
        xd = "the name is " + name +" The acoount number is "+  acctNum +" The balance is " + balance;
        return  xd;
    }

    // ----------------------------------------------
    // Deducts $10 service fee
    // ----------------------------------------------
    public double chargeFee() {

        balance = balance - 10.0;
        return balance;

    }

    // ----------------------------------------------
    // Changes the name on the account
    // ----------------------------------------------
    public void changeName(String newName)
    {
        this.name = newName;
    }
}
