public class Main {
    public static void main(String[] args) {

        Student s = new Student("Ali","Hazarta Muhalla","English , Urdu , Physics",'a');
        Teacher t = new Teacher("Abdul","Wow","Maths");
        s.activities();
        t.activities();
    }
}


abstract class Person{

    abstract void activities();

}

class Student extends Person{
    String name;
    String address;
    String courses;
    char grades;

    public Student() {
    }

    public Student(String name, String address, String courses, char grades) {
        this.name = name;
        this.address = address;
        this.courses = courses;
        this.grades = grades;
    }
    void activities()
    {
        System.out.println("The course enrolled by the student are " + courses);
    }
}


class Teacher extends Person{
    String name;
    String address;
    String courses;

    public Teacher() {
    }

    public Teacher(String name, String address, String courses) {
        this.name = name;
        this.address = address;
        this.courses = courses;
    }
    void activities()
    {
        System.out.println("The courses taught by the teacher are " + courses);
    }
}