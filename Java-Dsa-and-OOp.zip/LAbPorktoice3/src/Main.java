public class Main {
    public static void main(String[] args) {
        Data d1 = new Data();
        System.out.println(d1);

    }
}

class Data{
    String name = "Danyal";
    int age = 69;

   


}