import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

public class ToggleSwitch extends JFrame {

    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ToggleSwitch frame = new ToggleSwitch();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public ToggleSwitch() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btn = new JButton("ON");
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (btn.getText().equals("ON")) {
                    contentPane.setBackground(Color.YELLOW);
                    btn.setText("OFF");
                } else {
                    contentPane.setBackground(Color.WHITE);
                    btn.setText("ON");
                }
            }
        });
        btn.setBounds(216, 141, 154, 57);
        contentPane.add(btn);
    }

}