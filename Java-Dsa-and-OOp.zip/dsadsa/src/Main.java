public class Main {
    public static void main(String[] args) {
        int xd = 1000;
        int[] nums = {12 ,15 , 222, 1};

//        System.out.println(countDigits(xd));
        System.out.println(findNumbers(nums));
    }


    static int countDigits(int n)
    {
        int count = 0;
        while (n != 0)
        {
            n = n / 10;
            count++;
        }
        return count;
    }
    static int findNumbers(int[] nums) {
        int count = 0;
        int result = 0;
        int n;
        for(int i = 0 ; i < nums.length ; i++)
        {
            n = nums[i];
            while(n != 0)
            {
                n = n / 10;
                count++;
            }
            if(count % 2 == 0)
            {
                result++;
            }
            count = 0;

        }
        return count;
    }
}