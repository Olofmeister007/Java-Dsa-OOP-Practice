import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);


        Book book1 = new Book("Danyal",new Author("Danyal","danyalraxa007@gmail.com","male"),25.99,69);

        book1.getAuthor();


    }
}
class Book {
  private String name;


  Author author = new Author();
  ;
  private double price;
  private int qtyinstock;

    public Book(String name, Author author, double price, int qtyinstock) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.qtyinstock = qtyinstock;
    }
    public Book()
    {

    }

    String getName()
  {
      return name;
  }
  Author getAuthor()
    {
        System.out.println(author.name);
        System.out.println(author.email);
        System.out.println(author.gender);
       return  author;

    }
    double getPrice()
    {
        return price;
    }
    int getQtyinStock()
    {
        return qtyinstock;
    }

    void setPrice(double price1)
    {
        price = price1;

    }

    void setQtyinstock(int qtyInstock2)
    {
        qtyinstock = qtyInstock2;
    }


}
class Author {
    String name;
    String email;
    String gender;

    public Author(String name, String email, String gender) {
        this.name = name;
        this.email = email;
        this.gender = gender;


    }

    public Author ()
    {

    }

}

