
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Stack;


class Main {


   static int Prec(char ch)
    {
        switch (ch) {
            case '+':
            case '-':
                return 1;

            case '*':
            case '/':
                return 2;


        }
        return -1;
    }

    static boolean isOp(char op)
    {
        return op == '+' || op == '-' || op == '*' || op == '/';
    }


    static String infixToPostfix(String exp)
    {

        StringBuilder result = new StringBuilder(new String(""));


        Stack<Character> stack
                = new Stack<>();

        for (int i = 0; i < exp.length(); i++) {
            char c = exp.charAt(i);


            if (Character.isLetterOrDigit(c))
                result.append(c);


            else if (c == '(')
                stack.push(c);


            else if (c == ')') {
                while (stack.peek() != '(') {
                    result.append(stack.pop());

                }

                stack.pop();
            }
            else
            {
                while (!stack.isEmpty() && isOp(stack.peek())
                        && Prec(c) <= Prec(stack.peek())) {

                    result.append(stack.pop());

                }
                stack.push(c);
            }
        }


        while (!stack.isEmpty()) {

            result.append(stack.pop());
        }

        return result.toString();
    }


    public static void main(String[] args)
    {
        String exp = "(a-2*(b+c)-d*e)*f";

        System.out.println(infixToPostfix(exp));
    }
}




