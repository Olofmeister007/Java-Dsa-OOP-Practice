public class Main {
    public static void main(String[] args) {

        heap h1 = new heap(5);
        h1.insert(12);
        h1.insert(1);
        h1.insert(57);
        h1.insert(3);
        h1.insert(17);
        h1.print();
        h1.delete();
        System.out.println();
        h1.print();

    }

}

class heap {

    int size;
    int[] heap;

    heap(int capacity)
    {
        heap = new int[capacity];
    }


    void insert(int val)
    {
        heap[size] = val;
        size++;
        heapify(heap);
    }

    void heapify(int[] heap)
    {
        int currentIndex = size - 1 ;

        while(currentIndex > 0)
        {
            int Parent = (currentIndex - 1) / 2;
            if(heap[currentIndex] > heap[Parent])
            {
                int temp = heap[currentIndex];
                heap[currentIndex] = heap[Parent];
                heap[Parent] = temp;
            }
            currentIndex = Parent;
        }
    }

    void print()
    {
        for(int i=0 ; i<size ; i++)
        {
            System.out.println(heap[i]);
        }
    }

    void delete()
    {
        if(size < 1)
        {
            System.out.println("djsadsad");
            return;
        }
        heap[0] = heap[size - 1];
        size--;
        reHeapify(0);
    }

    void reHeapify(int index)
    {
        int leftChild = index  * 2 + 1;
        int rightChild = index * 2 + 2;
        int largest = index;

        if(leftChild < size && heap[leftChild] > heap[largest])
        {
            largest = leftChild;
        }
        if(rightChild < size && heap[rightChild] > heap[largest])
        {
            largest = rightChild;
        }

        if(largest != index)
        {
            int temp = heap[largest];
            heap[largest] = heap[index];
            heap[index] = temp;
            reHeapify(largest);
        }


    }
}