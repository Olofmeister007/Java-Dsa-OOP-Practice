public class Main {
    public static void main(String[] args){
        Book book3 = new Book();
        Book book4 = new Book();


        book3.initializeBook();
        book3.publisher = "xdddd";

        book4.copyBook(book3,book4);

        System.out.println(book4.id);

    }

}

class Book{

    String title;
    int id;
    String author1;
    String author2;
    String publisher;

    void initializeBook()
    {
        title = "Unknown";
        id = 1;
        author1 = "Unknown";
        author2 = "Unknown";
        publisher = "Unknown";
    }

    void copyBook (Book book1 , Book book2)
    {
        book2.publisher = book1.publisher;
        book2.author2 = book1.author2;
        book2.author1 = book1.author1;
        book2.title = book1.title;
        book2.id = book1.id;
    }

}