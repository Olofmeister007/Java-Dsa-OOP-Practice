import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        permutaion("", "abc");
        System.out.println(permutationsList("", "abcd"));
        System.out.println(permutationsCount("","abcd"));
        subset("", "abc");

        int[] xd= {1,2,3,4};
        String wow = Arrays.toString(xd);

        System.out.println(wow);



    }


    static void permutaion(String p, String up) {
        if (up.isEmpty()) {
            System.out.println(p);
            return;
        }

        char c = up.charAt(0);
        for (int i = 0; i <= p.length(); i++) {
            int end = p.length();
            String first = p.substring(0, i);
            String Second = p.substring(i, end);
            permutaion(first + c + Second, up.substring(1));
        }
    }

    static ArrayList<String> permutationsList(String p, String up) {
        if (up.isEmpty()) {
            ArrayList<String> list = new ArrayList<>();
            list.add(p);
            return list;
        }
        char ch = up.charAt(0);

        // local to this call
        ArrayList<String> ans = new ArrayList<>();

        for (int i = 0; i <= p.length(); i++) {
            String f = p.substring(0, i);
            String s = p.substring(i, p.length());
            ans.addAll(permutationsList(f + ch + s, up.substring(1)));
        }
        return ans;

    }

    static int permutationsCount(String p, String up) {
        if (up.isEmpty()) {

            return 1;
        }
        char ch = up.charAt(0);

        // local to this call

        int cur = 0;
        for (int i = 0; i <= p.length(); i++) {
            String f = p.substring(0, i);
            String s = p.substring(i, p.length());
            cur =  cur + permutationsCount(f + ch + s, up.substring(1));
        }

        return cur;
    }

    static void subset(String p, String up)
    {
        if(up.isEmpty())
        {
            System.out.println(p);
            return;
        }

        char ch = up.charAt(0);

        subset(p+ch, up.substring(1));
        subset(p, up.substring(1));
    }


    static void permutaionLeet(int[] p, int[] up) {
        if (up.length == 0) {
            System.out.println(p);
            return;
        }

        int z = up[0];
        for (int i = 0; i <= p.length; i++) {
            int end = p.length;
            String first = p.substring(0, i);
            String Second = p.substring(i, end);
            permutaionLeet(first + c + Second, up.substring(1));
        }
    }

}