import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main {
    public static void main(String[] args) {


        JFrame f = new JFrame();
        JTextField t = new JTextField(20);
        JTextArea tt = new JTextArea(5,20);
        JButton b = new JButton("Generate");
        t.setPreferredSize(new Dimension(150, 40));
        tt.setPreferredSize(new Dimension(200, 200));
        






        ActionListener a = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                if (e.getSource() == b) {
                    tt.setText("");
                    int n = Integer.parseInt(t.getText());
                    int  i,p,count,flag;


                    p=2;
                    i=1;
                    while(i<=n)
                    {
                        flag=1;
                        for(count=2;count<=p-1;count++)
                        {
                            if(p%count==0)  //Will be true if p is not prime
                            {
                                flag=0;
                                break;      //Loop will terminate if p is not prime
                            }
                        }
                        if(flag==1)
                        {
                            tt.setText(tt.getText() + 										"\n" + p);
                            i++;
                        }
                        p++;
                    }
                }

            }
        };


        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(new FlowLayout());
        f.add(t);
        f.add(b);
        f.add(tt);
        f.pack();
        f.setVisible(true);
        b.addActionListener(a);


    }
}








