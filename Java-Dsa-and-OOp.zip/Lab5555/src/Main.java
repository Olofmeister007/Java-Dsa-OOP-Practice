

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

public class Main extends JFrame {

    private JPanel contentPane;
    private JTextField textField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Main frame = new Main();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Main() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);

        JPanel panel = new JPanel();
        FlowLayout flowLayout = (FlowLayout) panel.getLayout();
        flowLayout.setHgap(55);
        contentPane.add(panel, BorderLayout.NORTH);

        textField = new JTextField();
        panel.add(textField);
        textField.setColumns(20);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        contentPane.add(textArea, BorderLayout.CENTER);

        JButton btnGenerate = new JButton("Generate");
        btnGenerate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textArea.setText("");
                int number = Integer.parseInt(textField.getText());
                int count = 0;
                int i = 2;
                while(count != number) {
                    if(primeCheck(i)) {
                        textArea.setText(textArea.getText() + 										"\n" + i);
                        count++;
                    }
                    i++;
                }
            }
        });
        panel.add(btnGenerate);

    }
    private boolean primeCheck(int num) {
        int factor = 0;
        for(int i = 1; i<=num; i++) {
            if(num % i == 0) {
                factor++;
            }
        }
        if(factor == 2)
            return true;
        else
            return false;
    }}
