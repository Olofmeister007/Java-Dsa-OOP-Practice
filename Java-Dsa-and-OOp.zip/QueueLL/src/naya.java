
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
    }
}
public class naya {
    public Node rear;
    public Node front;

    public naya() {
        front = null;
        rear = null;
    }

    public void enQueue(int val) {
        Node X = new Node(val);
        if (front == null) {
            front = X;
            rear = X;
        } else {
            rear.next = X;
            rear = X;
        }
    }

    public void deQueue() {
        if (front == null) {
            isEmpty();
        }

        else if (front == rear) {
            front = null;
            rear = null;
        }

        else {
            front = front.next;
        }
    }

    public void isEmpty() {
        if (front == null) {
            System.out.print("QUEUE is empty");
        }

    }

    public void print() {
        Node i;
        i = front;
        while (i != null) {

            System.out.print(i.data + "\n");
            i = i.next;
        }
    }

    public void printit() {
        Node i;
        i = front;
        int counter = 0;
        while (i != null) {

            System.out.print(i.data + "\n");
            counter++;
            i = i.next;
        }

        System.out.print("the length of Singly linked list is " + counter);
    }

    public static void main(String[] args) {
        naya q = new naya();
        q.enQueue(23);
        q.enQueue(24);
        q.enQueue(25);
        q.deQueue();

        q.print();
    }
}