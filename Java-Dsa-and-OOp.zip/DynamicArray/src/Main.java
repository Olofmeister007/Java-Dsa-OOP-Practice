import java.util.Arrays;

class DynamicArray2 {
    public int size;
    public int cap;

    public int arr[];



    DynamicArray2() {
        size = 0;
        cap = 4;
        arr = new int[cap];
    }

    public void insert(int n) {
        if (size < cap) {
            arr[size] = n;
            size++;
        }
        else {
            growSize();
            insert(n);

        }
        if(size < arr.length / 2)
        {
            shrinksize();
        }
    }

    public void growSize()
    {
        cap *=2;
        int temp[] = new int[cap];
        for(int i = 0; i<size ; i++)
        {
            temp[i] = arr[i];

        }
        arr = temp;
        temp = null;
    }

    public void print()
    {
        System.out.println("Printing Array....");
        for(int i =0 ; i<size ; i++)
        {
            System.out.print(arr[i]+", ");
        }
    }

    public void delete()
    {
        if(size > 0)
        {
            arr[size] = 0;
            size--;
        }
        else
        {
            System.out.println("No element in array");
        }
    }
    public void delete(int val)
    {
        boolean found = false;
        for(int i = 0 ; i < size  ; i++)
        {
            if(arr[i] == val)
            {
                found = true;
            }
            if(found && i < size - 1)
            {
               arr[i] = arr[i+1];
            }

        }

        if(found) {
            size--;
        }
        if(size < cap / 2)
        {
            shrinksize();
        }


    }
    public void deleteindex(int index)
    {
        boolean found = false;
        for(int i = 0 ; i < size ; i++)
        {
            if(i == index)
            {
                found = true;

            }
            if(found && i < size - 1)
            {
                arr[i] = arr[i+1];
            }

        }
        if(found)
        {
            size--;
        }

    }
    public void replace(int val , int numberToBeReplacedWith)
    {
        for(int i = 0 ; i < size ; i++)
        {
            if(arr[i] == val)
            {
                arr[i] = numberToBeReplacedWith;

            }

        }
    }
    public void shrinksize() {


                cap = cap / 2;
                int temp[] = new int[cap];
                for (int i = 0; i < size; i++) {
                    temp[i] = arr[i];
                }
                arr = temp;
                temp = null;


    }
}

public class Main {
    public static void main(String[] args) {

        DynamicArray2 d1 = new DynamicArray2();


        for(int i=0;i<100;i++)
        {
            d1.insert(i*2+9);
        }
        d1.print();


            d1.deleteindex(3);
            d1.replace(207 ,99);

        d1.print();


//        System.out.println("Size Before " + d1.arr.length);
//
//        System.out.println("Size After " + d1.arr.length);
    }
}