

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {


//        subseqAscii("", "abc");
//        System.out.println(subseqAsciiRet("", "abc"));
//        subseq("", "abc");
//        subseq2("","abc",0);
//        List<String> xd = new ArrayList<>();
//        subseq3("","abc",0,xd);
//        System.out.println(xd);
        int[] nums = {1,2,3};
        List<List<Integer>> ll=new ArrayList<>();
        generate(nums,0,new ArrayList<>(),ll);
        System.out.println(ll);
//        return ll;

        List<List<Integer>> ans = new ArrayList<List<Integer>>();
        helper(nums , 0 , new ArrayList<Integer>() , ans );
        System.out.println(ans);
//        return ans;

        List<List<Integer>> xd = new ArrayList<>();
        List<Integer> loc = new ArrayList<>();

        recurPermute(0, nums, xd);
        System.out.println(xd);
//        return xd;
    }

    public static void generate(int[] nums,int i,List<Integer> ls,List<List<Integer>> ll) {
        if (i == nums.length) {
            ll.add(new ArrayList(ls));
            return;
        }
        generate(nums, i + 1, ls, ll);
        ls.add(nums[i]);
        generate(nums, i + 1, ls, ll);
        ls.remove(ls.size() - 1);
    }

    public static void helper(int[] nums , int i , ArrayList<Integer> list , List<List<Integer>> ans)
    {
        if(i==nums.length)
        {
            ans.add(new ArrayList<>(list));
            return ;
        }
        helper(nums,i+1 , new ArrayList<>(list) , ans);
        list.add(nums[i]);
        helper(nums , i+1 , list , ans);
    }

    private static void recurPermute(int index, int[] nums, List < List < Integer >> ans) {
        if (index == nums.length) {
            // copy the ds to ans
            List < Integer > ds = new ArrayList < > ();
            for (int i = 0; i < nums.length; i++) {
                ds.add(nums[i]);
            }
            ans.add(new ArrayList < > (ds));
            return;
        }
        for (int i = index; i < nums.length; i++) {
            swap(i, index, nums);
            recurPermute(index + 1, nums, ans);
            swap(i, index, nums);
        }
    }
    private static void swap(int i, int j, int[] nums) {
        int t = nums[i];
        nums[i] = nums[j];
        nums[j] = t;
    }

    private void backtrack(List<List<Integer>> list, List<Integer> tempList, int [] nums) {
        if (tempList.size() == nums.length) {
            list.add(new ArrayList<>(tempList));
        } else {
            for (int i = 0; i < nums.length; i++) {
                if (tempList.contains(nums[i])) continue; // element already exists, skip
                tempList.add(nums[i]);
                backtrack(list, tempList, nums);
                tempList.remove(tempList.size() - 1);
            }
        }
    }

//    static void subseq(String p, String up) {
//        if (up.isEmpty()) {
//            System.out.println(p);
//            return;
//        }
//        char ch = up.charAt(0);
//        subseq(p + ch, up.substring(1));
//        subseq(p, up.substring(1));
//    }
//
//    static void subseq2(String p, String up, int index) {
//        if (index == up.length()) {
//            System.out.println(p);
//            return;
//        }
//        char ch = up.charAt(index);
//        subseq2(p + ch, up,index+1);
////        p.substring(0,index);
//        subseq2(p, up, index+1);
//    }
//
//    static void subseq3(String p, String up, int index, List<String> ans) {
//        if (index == up.length()) {
//            ans.add(p);
//            return;
//
//        }
//        char ch = up.charAt(index);
//        subseq3(p + ch, up,index+1,ans);
////        p.substring(0,index);
//        subseq3(p, up, index+1,ans);
//    }
//
//    static void permutaion(String p, String up, int index) {
//        if (index == up.length()) {
//            System.out.println(p);
//            return;
//        }
////        char ch = up.charAt(index);
////        subseq2(p + ch, up,index+1);
//////        p.substring(0,index);
////        subseq2(p, up, index+1);
//
//        for (int i = index; i < up.length(); i++) {
//            swap(i, index, nums);
//            recurPermute(index + 1, nums, ans);
//            swap(i, index, nums);
//        }
//
//
//    }
//
//    static ArrayList<String> subseqRet(String p, String up) {
//        if (up.isEmpty()) {
//            ArrayList<String> list = new ArrayList<>();
//            list.add(p);
//            return list;
//        }
//        char ch = up.charAt(0);
//        ArrayList<String> left = subseqRet(p + ch, up.substring(1));
//        ArrayList<String> right = subseqRet(p, up.substring(1));
//
//        left.addAll(right);
//        return left;
//    }
//
//    static void subseqAscii(String p, String up) {
//        if (up.isEmpty()) {
//            System.out.println(p);
//            return;
//        }
//        char ch = up.charAt(0);
//        subseqAscii(p + ch, up.substring(1));
//        subseqAscii(p, up.substring(1));
//        subseqAscii(p + (ch+0), up.substring(1));
//    }
//
//    static ArrayList<String> subseqAsciiRet(String p, String up) {
//        if (up.isEmpty()) {
//            ArrayList<String> list = new ArrayList<>();
//            list.add(p);
//            return list;
//        }
//        char ch = up.charAt(0);
//        ArrayList<String> first = subseqAsciiRet(p + ch, up.substring(1));
//        ArrayList<String> second = subseqAsciiRet(p, up.substring(1));
//        ArrayList<String> third = subseqAsciiRet(p + (ch+0), up.substring(1));
//
//        first.addAll(second);
//        first.addAll(third);
//        return first;
//    }
}