public class Main {
    public static void main(String[] args) {
        int[] arr = {1 , 2 ,3 ,4 ,5};

        xd(10);
        System.out.println(fact(5));
        System.out.println(min1(arr,arr.length));
        System.out.println(max(arr,arr.length));

        System.out.println(sum(1234));


        System.out.println(rev(1234,0));
        System.out.println(countZeros(123000,0));


    }

    static void xd(int n){
        if(n == 0) {
            return;
        }
        System.out.println(n);
        xd(n-1);
        System.out.println(n);
    }

    static int fact(int n){
        if(n == 0 || n == 1)
        {
            return 1;
        }

        return n * fact(n-1);
    }

    static int min1(int[] arr  , int n)
    {
        if(n == 1)
        {
            return arr[0];
        }

        return Math.min(arr[n-1] , min1(arr , n-1));

    }

    static int max(int[] arr , int n)
    {
        if(n == 1)
        {
            return arr[0];
        }


        return Math.max(arr[n-1] , max(arr , n-1));

    }



    static int sum(int n)
    {
        if(n == 0)
        {
            return 0;
        }

        return sum(n / 10) + n % 10;
    }

    static int rev(int n , int sum)
    {
        if(n == 0)
        {
            return sum;
        }
        int rem = n % 10;
        sum = sum * 10 + rem;
        return rev(n/10,sum);
    }

    static int countZeros(int n, int count)
    {
        if(n == 0)
        {
            return count;
        }
        if(n % 10 == 0)
        {
            return countZeros(n/10 , count+1);
        }
        return countZeros(n/10 , count);
    }




}
