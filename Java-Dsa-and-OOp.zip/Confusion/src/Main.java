class Solution {
    public static int oddCells(int n, int m, int[][] indices) {
        int[][] cells = new int[n][m];
        int result = 0;
        for(int i = 0; i < n; i++){
            for(int j = 0; j < m; j++)
                cells[i][j] = 0;
        }
        for(int[] indice: indices){
            for(int i = 0; i < m; i++){
                cells[indice[0]][i] = cells[indice[0]][i] + 1;
            }
            for(int i = 0; i < n; i++){
                cells[i][indice[1]] = cells[i][indice[1]] + 1;
            }
        }
        for(int[] cell : cells){
            for(int i : cell){
                if(i%2 != 0) result++;
            }
        }
        return result;
    }
}