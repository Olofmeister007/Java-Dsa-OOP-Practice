import java.util.Scanner;
import javax.swing.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        String name, first,first1, middle,middle1, last, space, monogram, xd;
        char zd;

        space = " ";
        String specialCharacters = "!@#$%&*()'+,-./:;<=>?[]^_`{|}";

        name = JOptionPane.showInputDialog(null, "Enter your full name first middle and last");

        for(int i = 0; i<name.length();i++) {
            char ch = name.charAt(i);
            if (specialCharacters.contains(Character.toString(ch))) {
                JOptionPane.showMessageDialog(null, "Name cannot contain special character");
                System.exit(0);
            }
        }





        first = name.substring(0, name.indexOf(space));
        name = name.substring(name.indexOf(space) + 1, name.length());


        middle = name.substring(0, name.indexOf(space));
        last = name.substring(name.indexOf(space) + 1, name.length());


        monogram = first.substring(0, 1) + middle.substring(0, 1) + last.substring(0, 1);

        JOptionPane.showMessageDialog(null, "Monogram is " + monogram);
    }

}



