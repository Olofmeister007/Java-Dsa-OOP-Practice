import java.util.Stack;

public class Main {
    public static void main(String[] args) {

        String exp = "(a-2*(b+c)-d*e)*f";
        String exp2 = "(a-b/c)*(a/k-l)";
        String exp3 = "k+l-m*n+(o*p)*w/u/v*t+q";
        String exp4 = "231*+9-";
        String exp5 = "-+7*45+20";
        System.out.println(infixToPostFix(exp));
        System.out.println(infixToPreFix(exp));
//        System.out.println(infToPre(exp2));
//        System.out.println(infToPre(exp3));
        System.out.println(postFixEva(exp4));
        System.out.println(preFixEva(exp5));
//
    }


    static int whatIs(char c) {
        if (Character.isLetterOrDigit(c)) {
            return 1;
        } else if (c == '+' || c == '-' || c == '*' || c == '/') {
            return 2;
        } else if (c == '(' || c == ')') {
            return 3;
        }
        return -1;
    }

    static int prec(char c) {
        if (c == '+' || c == '-') {
            return 1;
        } else if (c == '*' || c == '/') {
            return 2;
        }
        return -1;
    }


    static String infixToPostFix(String S) {
        Stack<Character> xd1 = new Stack<>();
        StringBuilder result = new StringBuilder();


        for (int i = 0; i < S.length(); i++) {
            char c = S.charAt(i);

            switch (whatIs(c)) {
                case 1 -> result.append(c);

                case 2 -> {
                    while (!xd1.isEmpty() && whatIs(xd1.peek()) == 2 && prec(c) <= prec(xd1.peek()))
                        result.append(xd1.pop());
                    xd1.push(c);
                }
                case 3 -> {
                    if (c == '(') xd1.push(c);

                    else if (c == ')') {
                        while (!xd1.isEmpty() && xd1.peek() != '(') {
                            result.append(xd1.pop());
                        }
                        if (!xd1.isEmpty()) {
                            xd1.pop();
                        }
                    }
                }
                default -> {
                    return "LOL NOOB";
                }
            }

        }
        while (!xd1.isEmpty()) {
            result.append(xd1.pop());
        }

        return result.toString();
    }

    static String infixToPreFix(String S) {
        Stack<Character> xd1 = new Stack<>();
        StringBuilder rev = new StringBuilder(S);
        StringBuilder result = new StringBuilder();

        rev.reverse();


        for (int i = 0; i < rev.length(); i++) {
            char c = rev.charAt(i);

            switch (whatIs(c)) {
                case 1 -> result.append(c);

                case 2 -> {
                    while (!xd1.isEmpty() && whatIs(xd1.peek()) == 2 && prec(c) <= prec(xd1.peek()))
                        result.append(xd1.pop());
                    xd1.push(c);
                }
                case 3 -> {
                    if (c == ')') xd1.push(c);

                    else if (c == '(') {
                        while (!xd1.isEmpty() && xd1.peek() != ')') {
                            result.append(xd1.pop());
                        }
                        if (!xd1.isEmpty()) {
                            xd1.pop();
                        }
                    }
                }
                default -> {
                    return "LOL NOOB";
                }
            }

        }
        while (!xd1.isEmpty()) {
            result.append(xd1.pop());
        }

        result.reverse();

        String s = result.toString();
        return s;
    }

    static int postFixEva(String S) {
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < S.length(); i++) {
            char c = S.charAt(i);

            if (Character.isDigit(c))
                stack.push(c - '0');

            else {
                int val1 = stack.pop();
                int val2 = stack.pop();

                switch (c) {
                    case '+' -> stack.push(val2 + val1);
                    case '-' -> stack.push(val2 - val1);
                    case '/' -> stack.push(val2 / val1);
                    case '*' -> stack.push(val2 * val1);
                }
            }
        }
        return stack.pop();

    }
    static int preFixEva(String xd2)
    {
        Stack<Integer> stack=new Stack<>();
        StringBuilder xd = new StringBuilder(xd2);
        xd.reverse();

        for(int i=0;i<xd.length();i++)
        {
            char c=xd.charAt(i);

            if(Character.isDigit(c))
                stack.push(c - '0');

            else
            {
                int val2 = stack.pop();
                int val1 = stack.pop();

                switch (c) {
                    case '+' -> stack.push(val2 + val1);
                    case '-' -> stack.push(val2 - val1);
                    case '/' -> stack.push(val2 / val1);
                    case '*' -> stack.push(val2 * val1);
                }
            }
        }
        return stack.pop();
    }


}
