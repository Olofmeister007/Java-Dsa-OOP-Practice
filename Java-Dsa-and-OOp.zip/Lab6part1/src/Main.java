

import java.util.Scanner;

class Information {
    int id;
    double sales;

    public Information(int id, double sales) {
        this.id = id;
        this.sales = sales;
    }

    public int getId() {
        return this.id;
    }

    public double getSales() {
        return this.sales;
    }
}

public class Main {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        int id;
        int sales;
        double total = 0;
        double average = 0;
        double max = 0;
        double min = 0;
        int tot = 0;
        int idNo = 0;
        int idNo2 = 0;
        Information[] Salesperson;
        System.out.println("Enter the number of Salesperson");
        int ar = input.nextInt();
        Salesperson = new Information[ar];
        for (int i = 0; i < Salesperson.length; i++) {
            System.out.println("Enter the id of Salesperson " + (i + 1));
            id = input.nextInt();
            if (id <= 0) {
                System.out.println("Error");
                System.exit(0);
            }
            System.out.println("Enter the Sales of Salesperson " + (i + 1));
            sales = input.nextInt();
            Salesperson[i] = new Information(id, sales);

            if (i == 0) {
                max = Salesperson[0].getSales();
                min = Salesperson[0].getSales();
            }

            System.out.println();

            if (Salesperson[i].getSales() >= max) {
                max = Salesperson[i].getSales();
                idNo = Salesperson[i].getId();
            } else {
                min = Salesperson[i].getSales();
                idNo2 = Salesperson[i].getId();
            }
            total = total + Salesperson[i].getSales();

            if (i == Salesperson.length - 1) {
                System.out.println();
                System.out.println("Enter a value");
                double value = input.nextInt();
                for (int j = 0; j < Salesperson.length; j++) {
                    if (Salesperson[j].getSales() > value) {
                        System.out.println(
                                "Salesperson: " + Salesperson[j].getId() + " with sales: " + Salesperson[j].getSales());
                        tot += 1;

                    }
                }
            }
        }
        System.out.println("total number of people who exceed value: " + tot);
        System.out.println();
        System.out.println("max: " + max + " of Salesperson: " + idNo);
        System.out.println("min: " + min + " of Salesperson: " + idNo2);
        average = total / Salesperson.length;
        System.out.println("The average sales is: " + average);

    }
}



