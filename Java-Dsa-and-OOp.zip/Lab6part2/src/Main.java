

import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        Integer[] values;
        Integer temp = 0;
        Integer temp2 = 0;

        System.out.print("How big should the array be: ");
        int size = input.nextInt();
        values = new Integer[size];

        for (int i = 0; i < values.length; i++) {
            System.out.println("Enter the value of index " + (i + 1));
            values[i] = input.nextInt();

            if (i == values.length - 1) {
                for (int j = 0; j < values.length; j++) {
                    if (j == 0) {
                        System.out.println("Original array");
                    }
                    System.out.println(values[j]);
                }
            }

        }
        for (int a = 0; a < values.length / 2; a++) {
            temp = values[a];
            values[a] = values[values.length - a - 1];
            values[values.length - a - 1] = temp;

        }
        System.out.println("Reversed array");
        for (int j = 0; j < values.length; j++) {
            System.out.println(values[j]);
        }
    }
}


