public class Main {
    public static void main(String[] args) {

        Bicycle ob1 = new Bicycle("ooga");
        Bicycle ob2 = new Bicycle("suka");



        ob1 = ob2 ;
        ob1.name = "blyat";



        System.out.println(ob2.name);
        System.out.println(Bicycle.population);

    }
}

class Bicycle {

    String name;
    static int population = 0;

    public Bicycle(String name ) {
        this.name = name;
        Bicycle.population++;
    }
}


