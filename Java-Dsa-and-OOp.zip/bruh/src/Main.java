
// ****************************************************************
// Dog.java
//
// A class that holds a dog's name and can make it speak.
//
// ****************************************************************
abstract class Dog {
    protected String name;

    // ------------------------------------------------------------
    // Constructor -- store name
    // ------------------------------------------------------------

    public Dog(String name) {
        this.name = name;
    }

    // ------------------------------------------------------------
    // Returns the dog's name
    // ------------------------------------------------------------
    public String getName() {
        return name;
    }

    // ------------------------------------------------------------
    // Returns a string with the dog's comments
    // ------------------------------------------------------------
    public String speak() {
        return "Woof";
    }

    public abstract int avgBreedWeight();
}

//****************************************************************
//Labrador.java
//
//A class derived from Dog that holds information about
//a labrador retriever. Overrides Dog speak method and includes
//information about avg weight for this breed.
//
//****************************************************************
class Labrador extends Dog {
    private String color; // black, yellow, or chocolate?
    private int breedWeight = 75;

    public Labrador(String name, String color) {
        super(name);
        this.color = color;
    }

    // ------------------------------------------------------------
// Big bark -- overrides speak method in Dog
// ------------------------------------------------------------
    @Override
    public String speak() {
        return "WOOF";
    }

    // ------------------------------------------------------------
// Returns weight
// ------------------------------------------------------------
    @Override
    public int avgBreedWeight() {
        return breedWeight;
    }

    public String getColor() {
        return this.color;
    }
}

//****************************************************************
//Yorkshire.java
//
//A class derived from Dog that holds information about
//a Yorkshire terrier. Overrides Dog speak method.
//
//****************************************************************
class Yorkshire extends Dog {
    private int breedWeight = 8;

    public Yorkshire(String name) {
        super(name);
    }

    // ------------------------------------------------------------
// Small bark -- overrides speak method in Dog
// ------------------------------------------------------------
    @Override
    public String speak() {
        return "woof";
    }

    @Override
    public int avgBreedWeight() {
        return breedWeight;
    }
}

public class Main {
    public static void main(String[] args) {
        Labrador dog = new Labrador("Alex", "orange");
        System.out.println(dog.getName() + " says " + dog.speak());
        System.out.println("average weight: " + dog.avgBreedWeight() + "pounds" + "\ncolor: " + dog.getColor());
    }

}



