import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main{
    public static void main(String[] args) {
        int n = 4;
        boolean[][] board = new boolean[n][n];
        System.out.println(queens(board, 0));
        nQueens2(board,0);
        ArrayList<String> xd = new ArrayList<>();
        ArrayList<ArrayList<String>> ans = new ArrayList<>();
        queens3(board, 0,xd,ans);
        System.out.println(ans);
    }

    static int queens(boolean[][] board, int row) {
        if (row == board.length) {
            display(board);
            System.out.println();
            return 1;
        }

        int count = 0;

        // placing the queen and checking for every row and col
        for (int col = 0; col < board.length; col++) {
            // place the queen if it is safe
            if(isSafe2(board, row, col)) {
                board[row][col] = true;
                count += queens(board, row + 1);
                board[row][col] = false;
            }
        }

        return count;
    }

    private static boolean isSafe(boolean[][] board, int row, int col) {
        // check vertical row
        for (int i = 0; i < row; i++) {
            if (board[i][col]) {
                return false;
            }
        }

        // diagonal left
        int maxLeft = Math.min(row, col);
        for (int i = 1; i <= maxLeft; i++) {
            if(board[row-i][col-i]) {
                return false;
            }
        }

        // diagonal right
        int maxRight = Math.min(row, board.length - col - 1);
        for (int i = 1; i <= maxRight; i++) {
            if(board[row-i][col+i]) {
                return false;
            }
        }

        return true;
    }

    private static void display(boolean[][] board) {
        for(boolean[] row : board) {
            for(boolean element : row) {
                if (element) {
                    System.out.print("Q ");
                } else {
                    System.out.print("X ");
                }
            }
            System.out.println();
        }
    }

    static void nQueens2(boolean[][] board, int r)
    {
        if(r == board.length)
        {
            display(board);
            System.out.println();
        }

        for(int c= 0 ; c<board.length ; c++)
        {
            if(isSafe2(board , r , c))
            {
                board[r][c] = true;
                nQueens2(board, r+1);
                board[r][c] = false;
            }
        }
    }

    static boolean isSafe2(boolean[][] board , int r, int c)
    {
        for(int i = 0 ; i < r ; i++)
        {
            if(board[i][c])
            {
                return false;
            }
        }

        int maxLeft = Math.min(r, c);
        for(int i = 1; i <= maxLeft ; i++)
        {
            if(board[r-i][c-i])
            {
                return false;
            }

        }

        int maxRight = Math.min(r, board.length - c - 1);
        for(int i = 1; i <= maxRight ; i++)
        {
            if(board[r-i][c+i])
            {
                return false;
            }

        }

        return true;
    }


    static ArrayList<ArrayList<String>>  queens3(boolean[][] board, int row, ArrayList<String> xd ,ArrayList<ArrayList<String>> ans) {
        if (row == board.length) {

            ans.add(new ArrayList<>(xd));
            return ans;
        }


        // placing the queen and checking for every row and col
        for (int col = 0; col < board.length; col++) {
            // place the queen if it is safe
            if(isSafe2(board, row, col)) {
                board[row][col] = true;
                char[] charArray = new char[board.length];
                Arrays.fill(charArray, '.');
                charArray[col] ='Q';
                String pepega = new String(charArray);
                xd.add(pepega);
                 queens3(board, row + 1, xd, ans);
                board[row][col] = false;
                xd.remove(xd.size()-1);

            }

        }

        return ans;

    }

}