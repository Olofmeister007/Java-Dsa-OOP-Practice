import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        print(5,0);
        print2(2,0);
        int [] arr = {5,4,3,2,1};
        System.out.println();
//        bubbleSortRecur(arr,4,0);
//        selectionSortRecur(arr,4,0,0);
//        arr = mergeSort(arr);
        mergeSortInPlace(arr,0, arr.length);
        System.out.println(Arrays.toString(arr));





    }


    static void print(int r, int c)
    {
        if(r < 1)
        {
            return;
        }
       if(c < r)
       {
           System.out.print("*");
           print(r, c+1);
       }
       else {
           System.out.println();
           print(r - 1, 0);
       }


    }

    static void print2(int r, int c)
    {
        if(r < 1)
        {
            return;
        }
        if(c < r)
        {
            print2(r, c+1);
            System.out.print("*");

        }
        else {
            print2(r - 1, 0);
            System.out.println();

        }


    }

    static void bubbleSortRecur(int[] arr, int r, int c)
    {
        if(r < 1)
        {
            return;
        }
        if(c < r)
        {
            if(arr[c] > arr[c+1])
            {
                int temp = arr[c];
                arr[c] = arr[c+1];
                arr[c+1] = temp;
                bubbleSortRecur(arr,r,c+1);
            }
        }
        else {

            bubbleSortRecur(arr,r - 1, 0);
        }

    }
    static void selectionSortRecur(int[] arr, int r, int c, int max)
    {
        if(r < 1)
        {
            return;
        }
        if(c <= r)
        {
            if(arr[c] > arr[max])
            {
                selectionSortRecur(arr,r,c+1,c);
            }
            else {
                selectionSortRecur(arr,r,c+1,max);
            }



        }
        else {
            int temp = arr[max];
            arr[max] = arr[r];
            arr[r] = temp;
            selectionSortRecur(arr,r - 1, 0, 0);
        }


    }

    static int[] mergeSort(int[] arr)
    {

            if(arr.length == 1)
            {
                return arr;
            }
            int mid = arr.length / 2;

            int[] left = mergeSort(Arrays.copyOfRange(arr,0,mid));
            int[] right = mergeSort(Arrays.copyOfRange(arr, mid, arr.length));

            int[] sorted = new int[left.length + right.length];

            int i = 0;
            int j = 0;
            int k = 0;

            while(i < left.length && j < right.length)
            {
                if (left[i] < right[j]) {
                    sorted[i] = left[i];
                    i++;
                }
                else {
                    sorted[j] = right[j];
                    j++;
                }
                k++;
            }

            while(i < left.length)
            {
                sorted[k] = left[i];
                i++;
                k++;
            }

            while(j < right.length)
            {
            sorted[k] = right[j];
            j++;
            k++;
              }

            return sorted;
    }


    static void mergeSortInPlace(int[] arr, int s, int e) {
        if (e - s == 1) {
            return;
        }

        int mid = (s + e) / 2;

        mergeSortInPlace(arr, s, mid);
        mergeSortInPlace(arr, mid, e);

        mergeInPlace(arr, s, mid, e);
    }

    private static void mergeInPlace(int[] arr, int s, int m, int e) {
        int[] mix = new int[e - s];

        int i = s;
        int j = m;
        int k = 0;

        while (i < m && j < e) {
            if (arr[i] < arr[j]) {
                mix[k] = arr[i];
                i++;
            } else {
                mix[k] = arr[j];
                j++;
            }
            k++;
        }

        // it may be possible that one of the arrays is not complete
        // copy the remaining elements
        while (i < m) {
            mix[k] = arr[i];
            i++;
            k++;
        }

        while (j < e) {
            mix[k] = arr[j];
            j++;
            k++;
        }

        for (int l = 0; l < mix.length; l++) {
            arr[s+l] = mix[l];
        }
    }



}