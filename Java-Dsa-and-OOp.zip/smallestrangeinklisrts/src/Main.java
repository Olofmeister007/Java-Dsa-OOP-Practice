import java.lang.reflect.Array;
import java.util.*;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;


public class Main {
    public static void main(String[] args) {

        ArrayList<ArrayList<Integer>> meow = new ArrayList<>();

        ArrayList<Integer> numbers = new ArrayList<>(Arrays.asList(4,10,15,24,26));
        ArrayList<Integer> numbers2 = new ArrayList<>(Arrays.asList(0,9,12,20));
        ArrayList<Integer> numbers3 = new ArrayList<>(Arrays.asList(5,18,22,30);

        meow.add(numbers);
        meow.add(numbers2);
        meow.add(numbers3);

    }


    public class Solution {
        class Node {
            int data;
            int row;
            int col;

            public Node(int data, int row, int col) {
                data = data;
                row = row;
                col = col;
            }
        }

        public int[] smallestRange(List<List<Integer>> nums) {
            int[] ans = {-1, -1};
            PriorityQueue<Node> pq = new PriorityQueue<Node>(new Comparator<Node>() {
                public int compare(Node a, Node b) {
                    return a.data - b.data;
                }
            });

            int min = Integer.MAX_VALUE;
            int max = Integer.MIN_VALUE;

            for (int i = 0; i < nums.size(); i++) {
                int var = nums.get(i).get(0);
                Node e = new Node(var, i, 0);
                max = Math.max(max, var);
                pq.offer(e);
            }

            int start = min;
            int end = max;

            while (pq.size() == nums.size()) {
                Node temp = pq.poll();
                min = temp.data;

                if (max - min < end - start) {
                    start = min;
                    end = max;
                }

                if (temp.col + 1 < nums.get(min).size()) {
                    max = Math.max(max, nums.get(temp.row).get(temp.col + 1));
                    Node newNode = new Node(nums.get(temp.row).get(temp.col + 1), temp.row, temp.col + 1);
                    pq.offer(newNode);

                } else {
                    break;
                }


            }
            ans[0] = start;
            ans[1] = end;
            return ans;
        }


    }



}

