public class Main {
    public static void main(String[] args) {

        System.out.println(findTheWinner(6,5));

    }


    public static int findTheWinner(int n, int k) {

        int[] arr = new int[n];
        for(int i = 0 ; i< n ; i++)
        {
            arr[i] = i+1;
        }

       return helper(arr, k, 0);


    }

    public static int helper(int[] arr, int k, int start) {
        int[] xd = new int[arr.length - 1];
        if (arr.length == 1) {
            int ans = arr[0] - 1;
            return ans;

        } else {

            int remove = (start + k) % arr.length;

            int j = 0;
            for (int i = 0; i < arr.length && j < xd.length; i++) {
                if (arr[i] != arr[remove]) {
                    xd[j] = arr[i];
                    j++;
                }
            }

            int ans =  (helper(xd, k, remove % xd.length) + 1) % arr.length;
            return ans;

        }
    }

}