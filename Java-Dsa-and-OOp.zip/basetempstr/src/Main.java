public class Main {
    public static void main(String[] args)
    {
        Base newBase = new Base();
        Base updatedBase = newBase.updatestr();

        String str3 = updatedBase.str2.substring(1,6);
        int index = str3.indexOf("v");
        str3 = str3.replace("v","@");

        System.out.println(updatedBase.str1);
        System.out.println(updatedBase.str2);
        System.out.println(index);
        System.out.println(str3);
        System.out.println(str3.length());
    }
}

class Base {
    String str1;
    String str2;

    public Base ()
    {
        this.str1 = "OOP";
        this.str2 = "In Java";
    }
    public Base updatestr()
    {
        Base temp = new Base();
        temp.str1 = "Java";
        temp.str2 = "For OOp";
        temp.str2 = temp.str1 + " " + temp.str2;
        return temp;
    }


}