public class Main {
    public static void main(String[] args) {

    }

    class Node {
        int data;
        Node left , right;

        public Node(int data) {
            this.data = data;

        }
    }

    class BST {
        Node root;

        void insert(Node root , int val)
        {
            Node r = root;
            if(r == null)
            {
                r.data = val;
            }
            else
            {
                while(r != null)
                {
                    if(val > r.data)
                    {
                        if(r.right != null)
                        {
                            r = r.right;
                        }
                        else
                        {
                            Node temp = new Node(val);
                            r.right = temp;
                            return;
                        }
                    }
                    else if (val < r.data)
                    {
                        if(r.left != null)
                        {
                            r = r.left;
                        }
                        else
                        {
                            Node temp = new Node(val);
                            r.left = temp;
                            return;
                        }
                    }
                }
            }
        }


    }


}