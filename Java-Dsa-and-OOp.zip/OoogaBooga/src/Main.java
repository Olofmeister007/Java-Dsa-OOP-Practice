import java.util.*;

public class Main {
    public static void main(String[] args) {

        Graph graph = new Graph(5);
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);
        graph.addEdge(3, 4);
        List<Integer> neighbors = graph.getNeighbors(2);

        graph.bfs(0);
        System.out.println();
        graph.dfs(0);
    }
}


class Graph{
    List <List<Integer>> adjacency = new ArrayList<>();
    int numNodes;




    public Graph(int numNodes) {
        this.numNodes = numNodes;
        this.adjacency = new ArrayList<>(numNodes);

        for(int i= 0 ; i < numNodes ; i++)
        {
            adjacency.add(new ArrayList<>());
        }
    }



    public void addEdge(int u, int v)
    {
        adjacency.get(u).add(v);

        adjacency.get(v).add(u);

    }

    public List<Integer> getNeighbors(int vertex)
    {
        return adjacency.get(vertex);
    }


    public void bfs(int vertex)
    {
        Queue<Integer> queue = new LinkedList<>();
        List<Integer> visited = new ArrayList<>();

        queue.add(vertex);
        visited.add(vertex);

        while(!queue.isEmpty())
        {
            int node = queue.poll();

            System.out.println(node);

            List<Integer> neighbours = getNeighbors(node);

            for(int neighbour : neighbours)
            {
                if(!visited.contains(neighbour))
                {
                    queue.add(neighbour);
                    visited.add(neighbour);
                }
            }
        }


    }

    public void dfs(int vertex)
    {
        Stack<Integer> stack = new Stack<>();
        List<Integer> visited = new ArrayList<>();

        stack.add(vertex);
        visited.add(vertex);

        while(!stack.isEmpty())
        {
            int node = stack.pop();

            System.out.println(node);

            List<Integer> neighbours = getNeighbors(node);

            for(int neighbour : neighbours)
            {
                if(!visited.contains(neighbour))
                {
                    stack.add(neighbour);
                    visited.add(neighbour);
                }
            }
        }


    }




}