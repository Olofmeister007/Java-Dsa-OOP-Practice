import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main {
    public static void main(String[] args) {

        JFrame f = new JFrame();
        JToggleButton b = new JToggleButton("Senior");
        JToggleButton c = new JToggleButton("Junior");
        JToggleButton d = new JToggleButton("Sophomore");
        JToggleButton h = new JToggleButton("Freshman");
        ActionListener a = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(b.isSelected()) {
                    JOptionPane.showMessageDialog(f ,"Senior");

                }
                else if (c.isSelected())
                {
                    JOptionPane.showMessageDialog(f ,"Junior");

                }
                else if(d.isSelected()) {
                    JOptionPane.showMessageDialog(f ,"Sophomore");

                }
                else if (h.isSelected()){
                    JOptionPane.showMessageDialog(f,"Freshman");
                }



            }
        };

        f.setSize(500,500);
        f.setLocationRelativeTo(null);
        f.setBounds(500,500,500,500);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.WHITE);
        f.add(b);
        f.add(c);
        f.add(d);
        f.add(h);
        Dimension size = b.getPreferredSize();
        b.setBounds(300, 180, size.width, size.height);
        c.setBounds(300, 240, size.width, size.height);
        d.setBounds(300, 280, size.width, size.height);
        h.setBounds(300, 320, size.width, size.height);
        b.addActionListener(a);
        c.addActionListener(a);
        d.addActionListener(a);
        h.addActionListener(a);


    }

}