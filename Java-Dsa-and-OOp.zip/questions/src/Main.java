import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) {

        int[] arr = {1 , 2  ,6 ,7,6};
        System.out.println(containsDuplicate(arr));

    }


    static boolean containsDuplicate(int[] arr )
    {
        HashSet<Integer> xd = new HashSet<>();
        for(int i = 0 ; i< arr.length ; i++)
        {
           if(xd.contains(arr[i])) {
               return true;
           }
           else
           {
               xd.add(arr[i]);
           }

        }
        return false;
    }
}