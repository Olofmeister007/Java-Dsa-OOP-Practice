

class RodCutting {
    public static int rodCutting(int[] length, int[] price, int n) {
        // length: list of lengths of rod pieces
        // price: list of prices of rod pieces
        // n: length of the rod

        // create an array to store the maximum values of the subproblems
        int[] dp = new int[n+1];

        for (int i = 1; i <= n; i++) {
            int maxValue = Integer.MIN_VALUE;
            for (int j = 0; j < i; j++) {
                maxValue = Math.max(maxValue, price[j] + dp[i-j-1]);
            }
            dp[i] = maxValue;
        }

        return dp[n];
    }

    public static void main(String[] args) {
        int[] length = {1, 2, 3, 4, 5, 6, 7, 8};
        int[] price = {3, 5, 8, 9, 10, 17, 17, 20};
        int n = 8;
        System.out.println(rodCutting(length, price, n)); // should output 22
    }
}
