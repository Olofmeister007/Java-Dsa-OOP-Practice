public class Main {
    public static void main(String[] args) {
        int[] piles = {30,11,23,4,20};
        int h = 6;

//        System.out.println(minEatingSpeed(piles,h));
//
//        int a = (int) Math.ceil(11 / ;
//        System.out.println(a);

        System.out.println(even(6));


    }

    public static int minEatingSpeed(int[] piles, int h) {
        int l = 1;
        int r = 0;
        int res = Integer.MAX_VALUE;
        for(int i=0 ; i<piles.length ; i++)
        {
            r = Math.max(piles[i], r);
        }

        while(l <= r)
        {
            int mid = l + (r - l) / 2;

            int hours = 0;
            for(int val : piles)
            {
                double cur= (val / mid) * 1.0;
                hours += Math.ceil(cur);
            }

            if(hours <= h)
            {
                res = Math.min(res, mid);
                r = mid - 1;
            }

            else
            {
                l = mid + 1;
            }

        }
        return res;

    }

    public static boolean even(int n)
    {
        return (n & 1) == 1;

    }
}