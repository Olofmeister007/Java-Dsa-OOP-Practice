public class Main {
    public static void main(String[] args) {

        A a = new A();
        a.m(2);
        a.m(1);
        a.m(0);
        a.m(-1);
        a.m(2);





    }
}

class A {
    public static double m(int x)
    {
        int y = x;
        try {
            System.out.println("one");
            y = 5 / x;
            System.out.println("two");
            return 5 / (x + 2);
        }

        catch(ArithmeticException e){

                System.out.println("three");
                y = 5 / (x + 1);
                System.out.println("four");
            }

            System.out.println("five");
            y = 4 / x;
            System.out.println("six");
            return 1 / x;


    }
}


