import java.text.DecimalFormat;
import java.util.*;

class BST {

    static class Node {
        int value;
        Node left;
        Node right;
        public Node(int value) {
            this.value = value;
            this.left = null;
            this.right = null;
        }
    }

    Node root;

    // Constructor for BST =>initial empty tree
    BST(){
        root = null;
    }


    public void insert(int value) {
        root = insert(root, value);
    }

    private Node insert(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }

        if (value < root.value) {
            root.left = insert(root.left, value);
        } else if (value > root.value) {
            root.right = insert(root.right, value);
        }

        return root;
    }

    public boolean search(int value) {
        return search(root, value);
    }

    private boolean search(Node root, int value) {
        if (root == null) {
            return false;
        }

        if (root.value == value) {
            return true;
        } else if (value < root.value) {
            return search(root.left, value);
        } else {
            return search(root.right, value);
        }
    }


    public void inorder() {
        inOrder(root);
    }

    private void inOrder(Node root) {
        if (root == null) {
            return;
        }

        inOrder(root.left);
        System.out.print(root.value + " ");
        inOrder(root.right);
    }

    public void preOrder() {
        preOrder(root);
    }

    private void preOrder(Node root) {
        if (root == null) {
            return;
        }

        System.out.print(root.value + " ");
        preOrder(root.left);
        preOrder(root.right);
    }

    public void postOrder() {
        postOrder(root);
    }

    private void postOrder(Node root) {
        if (root == null) {
            return;
        }

        postOrder(root.left);
        postOrder(root.right);
        System.out.print(root.value + " ");
    }

    public void delete(int value) {
        root = delete(root, value);
    }

    private Node delete(Node root, int value) {
        if (root == null) {
            return null;
        }

        if (value < root.value) {
            root.left = delete(root.left, value);
        } else if (value > root.value) {
            root.right = delete(root.right, value);
        } else {
            if (root.left == null && root.right == null) {
                return null;
            } else if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            } else {
                int minValue = findMinValue(root.right);
                root.value = minValue;
                root.right = delete(root.right, minValue);
            }
        }

        return root;
    }

    private int findMinValue(Node root) {
        while (root.left != null) {
            root = root.left;
        }
        return root.value;
    }


    int height()
    {

        return height(root);
    }

    private int height(Node root)
    {
        if(root == null)
        {
            return 0;
        }

        else
        {
            return Math.max(height(root.left) , height(root.right)) + 1;

        }

    }
//    private int height(Node root)
//    {
//        if(root == null)
//        {
//            return 0;
//        }
//        else
//        {
//            int left = height(root.left);
//            int right = height(root.right);
//            return Math.max(left , right) + 1;
//        }
//
//    }

    void path()
    {
        ArrayList<Integer> xd = new ArrayList<>();
        path(root , xd);
    }
    void path(Node root , ArrayList<Integer> xd)
    {
        if(root == null)
        {
            return;
        }

        xd.add(root.value);
        if(root.left == null && root.right == null)
        {
            printPath(xd);
            System.out.println();
        }
        else {
            path(root.left , xd);
            path(root.right, xd);
        }
        xd.remove(xd.size() - 1);

    }
    void printPath(ArrayList<Integer> xd)
    {
        for(int i=0 ; i< xd.size() ; i++)
        {
            System.out.print(xd.get(i)+ "->");
        }
    }

    public  Node inorderSuccessor(Node root, Node node) {
        if(node.right != null) {
            // case 1: if right subtree is not null, the inorder successor is the leftmost node in the right subtree
            node = node.right;
            while(node.left != null) {
                node = node.left;
            }
            return node;
        } else {
            // case 2: if right subtree is null, the inorder successor is the nearest ancestor whose left child is also an ancestor
            Node succ = null;
            while(root != null) {
                if(node.value < root.value) {
                    succ = root;
                    root = root.left;
                } else if(node.value > root.value) {
                    root = root.right;
                } else {
                    break;
                }
            }
            return succ;
        }
    }


    public  Node inorderPredecessor(Node root, Node node) {
        if(node.left != null) {
            // case 1: if left subtree is not null, the inorder predecessor is the rightmost node in the left subtree
            node = node.left;
            while(node.right != null) {
                node = node.right;
            }
            return node;
        } else {
            // case 2: if left subtree is null, the inorder predecessor is the nearest ancestor whose right child is also an ancestor
            Node pred = null;
            while(root != null) {
                if(node.value > root.value) {
                    pred = root;
                    root = root.right;
                } else if(node.value < root.value) {
                    root = root.left;
                } else {
                    break;
                }
            }
            return pred;
        }
    }
    public static boolean areIdentical(Node root1, Node root2) {
        if (root1 == null && root2 == null) {
            return true;
        }
        if (root1 == null || root2 == null) {
            return false;
        }
        return (root1.value == root2.value)
                && areIdentical(root1.left, root2.left)
                && areIdentical(root1.right, root2.right);
    }
    public void isValidBST(Node root) {
        System.out.println(isValidBST(root, Long.MIN_VALUE, Long.MAX_VALUE));
    }

    public boolean isValidBST(Node root, long minVal, long maxVal) {
        if (root == null) return true;
        if (root.value >= maxVal || root.value <= minVal) return false;
        return isValidBST(root.left, minVal, root.value) && isValidBST(root.right, root.value, maxVal);
    }

    public List<Integer> rightSideView(Node root) {
        List<Integer> list= new ArrayList();
        rightSideView(root,list,0);
        return list;
    }

    public void rightSideView(Node root,List<Integer> list, int level){
        if(root==null){
            return;
        }
        if(list.size()==level){
            list.add(level,root.value);
        }

        rightSideView(root.right,list,level+1);
        rightSideView(root.left,list,level+1);

    }

    public List<Integer> leftSideView(Node root) {
        List<Integer> list= new ArrayList();
        leftSideView(root,list,0);
        return list;
    }

    public void leftSideView(Node root,List<Integer> list, int level){
        if(root==null){
            return;
        }
        if(list.size()==level){
            list.add(level,root.value);
        }

        leftSideView(root.left,list,level+1);
        leftSideView(root.right,list,level+1);

    }

    public int Diameter(Node root)
    {
        if(root == null)
        {
            return 0;
        }

        int ld = Diameter(root.left);
        int rd = Diameter(root.right);

        int cur = height(root.left) + height(root.right) + 1;

        return Math.max(cur , Math.max(ld, rd));
    }

    public List<List<Integer>> bfs(Node node)
    {
        List<List<Integer>> result = new ArrayList<>();

        Queue<Node> xd = new LinkedList<>();

        xd.offer(node);
        while(!xd.isEmpty())
        {
            int currentLevelSize = xd.size();
            List<Integer> currentLevel = new ArrayList<>();

            for(int i = 0 ; i< currentLevelSize ; i++)
            {
                Node curr = xd.poll();

                if(curr != null)
                {
                    currentLevel.add(curr.value);
                }

                if(curr != null && curr.left != null)
                {
                    xd.offer(curr.left);
                }
                if(curr != null && curr.right != null)
                {
                    xd.offer(curr.right);
                }
            }
            result.add(currentLevel);


        }

        return result;
    }


}



class Main{
    public static void main(String[] args)  {
        //create a BST object
        BST bst = new BST();
//        /* BST tree example
//              45
//           /     \
//          10      90
//         /  \    /
//        7   12  50   */
//        //insert data into BST
//        bst.insert(45);
//        bst.insert(10);
//        bst.insert(7);
//        bst.insert(12);
//        bst.insert(90);
//        bst.insert(50);
//        //print the BST
//        System.out.println("The BST Created with input data(Left-root-right):");
//        bst.inorder();
//        System.out.println("The Paths in the bst are");
//        bst.path();
//
//        System.out.println("Whether bst is valid or NOt");
//        bst.isValidBST(bst.root);
//
//        System.out.println("right view of Tree");
//        System.out.println(bst.rightSideView(bst.root));
//
//        System.out.println("Left view of Tree");
//        System.out.println(bst.leftSideView(bst.root));
//
//
//
//        //delete leaf node
//        System.out.println("\nThe BST after Delete 12(leaf node):");
//        bst.delete(12);
//        bst.inorder();
//        //delete the node with one child
//        System.out.println("\nThe BST after Delete 90 (node with 1 child):");
//        bst.delete(90);
//        bst.inorder();
//
//        //delete node with two children
//        System.out.println("\nThe BST after Delete 45 (Node with two children):");
//        bst.delete(45);
//        bst.inorder();
//        //search a key in the BST
//        boolean ret_val = bst.search (50);
//        System.out.println("\nKey 50 found in BST:" + ret_val );
//        ret_val = bst.search (12);
//        System.out.println("\nKey 12 found in BST:" + ret_val );
//        System.out.println(bst.height());

        for(int i = 0 ; i< 20 ; i++)
        {
            bst.insert(i);
        }
        System.out.println("BFS");
        System.out.println(bst.bfs(bst.root));

    }
}