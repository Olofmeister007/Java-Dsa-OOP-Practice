import java.util.SortedMap;

// ****************************************************************
// DogTest.java
//
// A simple test class that creates a Dog and makes it speak.
//
// ****************************************************************
public class DogTest
{
    public static void main(String[] args)
    {
        Dog dog = new Dog("Spike");
        System.out.println(dog.getName() + " says " + dog.speak());

        Labrador l = new Labrador("Beast","Blue");
        Yorkshire y = new Yorkshire("Zulfiqar");
        System.out.println(l.speak());
        System.out.println(y.speak());
        System.out.println(l.avgBreedWeight());
        y.setBreedWeight(80);
        System.out.println(y.avgBreedWeight());
        

    }
}