import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        HashMap<Integer,Integer> wow= new HashMap<>();
        System.out.println(fibb(48));
        System.out.println(fib(48));

    }

    static HashMap<Integer , Integer> xd = new HashMap<>();
    static int fibb(int n)
    {
        if(xd.containsKey(n))
        {
            return xd.get(n);
        }
        if(n < 2)
        {
            return n;
        }

        int result = fibb(n-1) + fibb(n-2);
        xd.put(n,result);
        return result;
    }

    static int fib(int n)
    {
        if(n < 2)
        {
            return n;
        }


        return fib(n-1) + fib(n-2);
    }
}