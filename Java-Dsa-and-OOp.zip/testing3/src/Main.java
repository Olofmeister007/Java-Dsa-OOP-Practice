public class Main {
    public static void main(String[] args) {

        TollBooth xd = new TollBooth();
        xd.payingCar();
        xd.noPayCar();
        xd.display();
    }
}

class TollBooth{
    int carNumber;
    double totalMoney;

    public TollBooth() {
        carNumber = 0;
        totalMoney = 0.0;
    }

    void payingCar()
    {
        carNumber++;
        totalMoney += 50.0;
    }
    void noPayCar()
    {
        carNumber++;
    }
    void display()
    {
        System.out.println(carNumber);
        System.out.println(totalMoney);
    }
}