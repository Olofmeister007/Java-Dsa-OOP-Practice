import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        ArrayList<Integer> ans= new ArrayList<>();
       int N;
       int D;
       int A;
       int B;
       int C;
       int Y;
       N = scn.nextInt();
       D = scn.nextInt();
        A = scn.nextInt();
        B = scn.nextInt();

       int[] arr = new int[N];
       for(int i=0 ; i<N ; i++)
       {
           C = scn.nextInt();
           Y = scn.nextInt();
           arr[i] = C + Y;

       }

       for(int i=0 ; i<N ; i++)
       {
           if(arr[i] <= D)
           {
               D -= arr[i];
               ans.add(i+1);

           }
       }
        Collections.sort(ans , Collections.reverseOrder());
        System.out.println(ans.size());
        System.out.println(ans);

    }


}

