import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int height;
        int weight;
        double bmi;

        Scanner input = new Scanner(System.in);
        System.out.println("Enter your heigth in (cm)");
        height = input.nextInt();
        System.out.println("Enter your weight in (kg)");
        weight = input.nextInt();
        bmi = weight / Math.pow(height/100.0,2);

        if(bmi>=20 && bmi <=25)
        {
            System.out.println("Your bmi is "+bmi+" and it is normal");
        }
        else
        {
            System.out.println("Your bmi is "+bmi+" and it is not normal");

        }


    }
}