import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {

        BinarySearchTree bst = new BinarySearchTree();
        bst.insert(bst.root , 100);
        bst.insert(bst.root , 50);
        bst.insert(bst.root , 70);
        bst.insert(bst.root , 150);
        bst.insert(bst.root , 40);
        bst.insert(bst.root , 80);
        bst.insert(bst.root , 70);
        bst.insert(bst.root , 75);
        bst.inOrder(bst.root);
        bst.height(bst.root);
        System.out.println(bst.bfs(bst.root));

    }
}


class BinarySearchTree {
    class Node {
        int data;
        Node right;
        Node left;
        public Node(int data) {
            this.data = data;
        }

    }
    Node root;
    BinarySearchTree(){
        root = null;
    }
    public Node insert(Node root, int val)
    {
        if(root == null)
        {
            root = new Node(val);
            return root;
        }

        if(val < root.data)
        {
            root.left = insert(root.left , val);
        }
        else if(val > root.data)
        {
            root.right = insert(root.right , val);
        }

        return root;
    }
    public boolean search(Node root , int val)
    {
        if(root == null)
        {
            return false;
        }

        if(val < root.data)
        {
            return search(root.left , val);
        }
        else if(val > root.data)
        {
            return search(root.right , val);
        }
        else return val == root.data;
    }

    public void inOrder(Node root)
    {
        if(root == null)
        {
            return;
        }

        inOrder(root.left);
        System.out.println(root.data);
        inOrder(root.right);
    }

    public Node delete(Node root , int val)
    {
        if(root == null)
        {
            return root;
        }
         if(val < root.data)
        {
            root.left = delete(root.left , val);
        }
        else if(val > root.data)
        {
            root.right = delete(root.right , val);
        }
        else {
            if(root.right == null && root.left == null)
            {
                return null;
            }
            else if(root.left == null)
            {
                return root.right;
            }
            else if(root.right == null)
            {
                return root.left;
            }
            else {
                int min = minValue(root.right);
                root.data = min;
                root.right = delete(root.right , min);

            }
        }

        return root;
    }

    public int minValue(Node root)
    {
        while(root.left != null)
        {
            root = root.left;
        }
        int min = root.data;
        return min;

    }

    int height(Node root)
    {
        if(root == null)
        {
            return 0;
        }
        else {
            int left =  height(root.left);
            int right = height(root.right);
            return Math.max(left , right) + 1;
        }

    }
    public List<List<Integer>> bfs(Node node)
    {
        List<List<Integer>> result = new ArrayList<>();

        Queue<Node> xd = new LinkedList<>();

        xd.offer(node);
        while(!xd.isEmpty())
        {
            int currentLevelSize = xd.size();
            List<Integer> currentLevel = new ArrayList<>();

            for(int i = 0 ; i< currentLevelSize ; i++)
            {
                Node curr = xd.poll();

                if(curr != null)
                {
                    currentLevel.add(curr.data);
                }

                if(curr != null && curr.left != null)
                {
                    xd.offer(curr.left);
                }
                if(curr != null && curr.right != null)
                {
                    xd.offer(curr.right);
                }
            }
            result.add(currentLevel);


        }

        return result;
    }

}