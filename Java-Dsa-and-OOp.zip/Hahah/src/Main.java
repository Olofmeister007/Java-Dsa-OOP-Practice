import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        isPossible9();


    }

    static void isPossible9()
    {
        int N;
        int D;
        int A;
        int B;
        int size = 0;

        int[] arr = new int[6];
        Scanner scn = new Scanner(System.in);
        N = scn.nextInt();
        D = scn.nextInt();
        A = scn.nextInt();
        B = scn.nextInt();
        for(int i = 0 ; i< 6 ; i+= 2) {
            arr[i] = scn.nextInt();
            arr[i+1] = scn.nextInt();

        }
        for(int i = 0 ; i<=6 ; i+=2) {
            if (arr[i] * A + arr[i+1] * B <= D) {
                D = D - (arr[i] * A + arr[i+1] * B);
                size++;
                System.out.println(size);
                System.out.println(arr[i]);

            }

        }
        System.out.println(D);


    }


}

