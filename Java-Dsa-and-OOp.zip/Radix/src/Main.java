
import java.util.Arrays;

class RadixSort {
    static void countingSort(int[] array, int place) {
        int size = array.length;
        int[] output = new int[size];
        int[] count = new int[10];

        // Calculate count of elements
        for (int i = 0; i < size; i++) {
            int index = array[i] / place;
            count[index % 10]++;
        }

        // Calculate cumulative count
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        // Place the elements in sorted order
        for (int i = size - 1; i >= 0; i--) {
            int index = array[i] / place;
            output[count[index % 10] - 1] = array[i];
            count[index % 10]--;
        }

        System.arraycopy(output, 0, array, 0, size);
    }

    static void radixSort(int[] array) {
        int max_element = Arrays.stream(array).max().getAsInt();
        int place = 1;
        while (max_element / place > 0) {
            countingSort(array, place);
            place *= 10;
        }
    }

    static void printArray(int[] arr) {
        for (int i : arr) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] arr = {169, 44, 74, 89, 801, 23, 1, 65};
        System.out.print("Original array is: ");
        printArray(arr);

        radixSort(arr);

        System.out.print("Sorted Array in Ascending Order: ");
        printArray(arr);
    }
}
