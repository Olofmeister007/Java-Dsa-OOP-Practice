import javax.swing.JOptionPane;
public class Lab1point1 {
    public static void main (String[] args)
    {

        String name, first, middle, last, monogram;
        String specialCharacters = "!@#$%^&*()_+{}:;123456789<>?\'\".,[]~`";
        boolean flag = true;

        name = JOptionPane.showInputDialog(null, "Enter your full name");

        for (int i = 0; i < specialCharacters.length(); i++)
        {
            if (name.indexOf(specialCharacters.charAt(i)) != -1 ) { // indexOf gives -1 when that character is
                JOptionPane.showMessageDialog(null, "Error");       // not found in the string.
                flag = false;
                break;
            }
        }
        if (flag == true) {
            first = name.substring(0, name.indexOf(" "));
            name = name.substring(name.indexOf(" ")+ 1, name.length());
            middle = name.substring(0, name.indexOf(" "));
            last = name.substring(name.indexOf(" ")+ 1, name.length());
            monogram = first.substring(0,1) + middle.substring(0,1) + last.substring(0,1);
            JOptionPane.showMessageDialog(null, monogram);
        }
    }
}
