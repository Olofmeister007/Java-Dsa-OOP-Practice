import javax.print.DocFlavor;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        HashMap<Integer, Integer> ans = new HashMap<>();
        ArrayList<Integer> val = new ArrayList<>();
        ArrayList<Integer> ind = new ArrayList<>();



        int N;
        N = scn.nextInt();
        int D;
        D = scn.nextInt();
        int A;
        A = scn.nextInt();
        int B;
        B = scn.nextInt();
        int k;
        int L;


        int[] arr = new int[N];

        for(int i=0 ; i<N ; i++)
        {

            k = scn.nextInt();
            L = scn.nextInt();
            arr[i] = k+L;
            ans.put(arr[i],i+1);

        }
        Arrays.sort(arr);
        System.out.println(ans);
        System.out.println(Arrays.toString(arr));
//        for(int i=0 ; i< N; i++)
//        {
//
//        }


        Collections.sort(val);
        System.out.println(ans);
        System.out.println(val);

        for(int i=0 ; i<val.size(); i++)
        {
            System.out.print(ans.get(val.get(i))+" ");
        }




    }

}