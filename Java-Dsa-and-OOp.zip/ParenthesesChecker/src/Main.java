import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        String meow = "{([])}";

        System.out.println(part(meow));
    }
    static boolean part(String s)
    {
        Stack<Character> xd = new Stack<>();
        for(int i=0 ; i<s.length() ; i++)
        {
            if(s.charAt(i) == '{')
            {
                xd.push('}');
            }
            else if(s.charAt(i) == '(')
            {
                xd.push(')');
            }
            else if(s.charAt(i) == '[')
            {
                xd.push(']');
            }
            else if(xd.isEmpty() || xd.pop() != s.charAt(i))
            {
                return false;
            }


        }
        return xd.isEmpty();
    }


}


