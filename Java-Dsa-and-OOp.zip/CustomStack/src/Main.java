
import java.util.*;

public class Main {
    public static void main(String[] args) {
        int [][] isConnected = {{1,0,0},{0,1,0},{0,0,1}};
        System.out.println(findCircleNum(isConnected));
    }

    public static int findCircleNum(int[][] isConnected) {
        int V = isConnected.length;
        return numProvinces(isConnected, V);

    }

    private static void dfs(int node, int[][] adjLs , int[] vis)  {
        vis[node] = 1;
        for(int i=0; i< adjLs.length ; i++) {
            if(vis[i] == 0 && adjLs[node][i] == 1) {
                dfs(i, adjLs, vis);
            }
        }
    }
    private static int numProvinces(int[][] adj, int V) {

        int[] vis = new int[V];
        int cnt = 0;
        for(int i = 0;i<V;i++) {
            if(vis[i] == 0) {
                cnt++;
                dfs(i, adj, vis);
            }
        }
        return cnt;
    }
}

