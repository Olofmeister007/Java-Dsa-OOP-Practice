import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        Stack<Integer> st= new Stack<>();

        LinkedList<Integer> xd = new LinkedList<>();

        int[] arr = {1, 6,3,5,8};
//        int[] arr = {1, 2, 3, 4, 8, 5, 9};
        ArrayList<Integer> ans= new ArrayList<>();

        ans.add(arr[0]);

        for(int i=1 ; i<arr.length-1 ; i++)
        {
           if(arr[i] < arr[i+1] && arr[i] < arr[i-1])
           {
               ans.add(arr[i]);
           }
           else if(arr[i] > arr[i+1] && arr[i] < arr[i+2])
           {
               ans.add(arr[i]);
           }
        }
        ans.add(arr[arr.length-1]);

        System.out.println(ans);
    }
}