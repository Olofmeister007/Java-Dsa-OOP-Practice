public class Main {
    public static void main(String[] args) {
        QuestionOne q1 ;
        q1 = new QuestionOne();
        q1.init();
        q1.count = q1.increment() + q1.increment();
        System.out.println(q1.increment());

    }
}

class QuestionOne{
    public int count;
    public void init()
    {
        count = 1;
    }
    public int increment()
    {
        count +=1;
        return count;
    }

}
