import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Points p1 = new Points();

        p1.points();

    }

}

class Points {

    void points ()
    {
        System.out.println("Enter 1 if your Points are >= 100 and < 200");
        System.out.println("Enter 2 if your Points are >= 200 and < 300");
        System.out.println("Enter 3 if your Points are >= 300 and < 400");
        System.out.println("Enter 4 if your Points are >= 400 and < 500");
        System.out.println("Enter 5 if your Points are >= 500 \n");
        Scanner scn = new Scanner(System.in);
        int n = scn.nextInt();
        switch (n)
        {
            case 1:
            {
                System.out.println("You won a free cup of coffee.");
                break;
            }
            case 2:
            {
                System.out.println("You won a free cup of coffee and a regular-size doughnut");
                break;
            }
            case 3:
            {
                System.out.println("You won a free cup of coffee and a regular-size doughnut and a 12-oz orange juice.");
                break;
            }

            case 4:
            {
                System.out.println("You won a free cup of coffee and a regular-size doughnut and a 12-oz orange juice and a combo breakfast.");
                break;
            }
            case 5:
            {
                System.out.println("You won a free cup of coffee and a regular-size doughnut and a 12-oz orange juice and a combo breakfast and a reserved table for one week.");
                break;
            }
            default:
            {
                System.out.println("Invalid Input");
                break;
            }
        }

    }
}