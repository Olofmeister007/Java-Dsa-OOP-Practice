public class Main {
    public static void main(String[] args) {

        TemperatureConverter t1 = new TemperatureConverter();
        t1.setFahrenheit(86);
        t1.tocelsius();


        }
    }

class TemperatureConverter {
    private double celsius;
    private double fahrenheit;

    void tofahrenheit() {
        fahrenheit = (celsius * 9 / 5) + 32;
        System.out.println(fahrenheit);
    }

    void tocelsius() {
        celsius = (fahrenheit - 32) * 5 / 9;
        System.out.println(celsius);
    }


    void setCelsius(double n) {
        celsius = n;
    }

    void setFahrenheit(double m) {
        fahrenheit = m;
    }

}