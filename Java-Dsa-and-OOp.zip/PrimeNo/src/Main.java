import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        check(2);

    }

    static void check(int test) {

        Scanner scn = new Scanner(System.in);
        test = scn.nextInt();

        int a , b , sum;


        for (int i = 1; i <= test; i++) {

            a = scn.nextInt();
            b = scn.nextInt();

            if (isPrime(a) && isPrime(b)) {
                sum = a + b;
                System.out.println("Case #" + i + ": " + sum);
            } else if (isPrime(a) || isPrime(b)) {
                sum = a * b;
                System.out.println("Case #" + i + ": " + sum);
            } else {
                System.out.println("Not Possible");
            }

        }
    }


    static boolean isPrime(int n)
    {
        if(n <= 1)
        {
            return false;
        }

        for(int i =2 ; i<= n / 2 ; i++)
        {
            if (n % i == 0)
            {
                return false;
            }
        }
        return true;
    }
}