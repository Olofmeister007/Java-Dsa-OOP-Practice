import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        int[] candidates = {2,3,6,7};
        List<Integer> p = new ArrayList<>();
        int target = 7;
        List<List<Integer>> xd = new ArrayList<>();

//        diceRet(candidates,target,p,xd,0);
        getResult(xd,p,candidates,target,0);
        System.out.println(xd);

//        diceFace("",target,candidates);
    }


    public static void diceRet(int[] candidates, int target, List<Integer> p, List<List<Integer>> list, int start) {
        if (target == 0) {
            list.add(new ArrayList<>(p));
            return;
        }

        // List<Integer> p1 = new ArrayList<>();
        if(target > 0) {
            for (int i = start; i < candidates.length && candidates[i] <= target; i++) {
                p.add(candidates[i]);
                diceRet(candidates, target - candidates[i], p, list,i);
                p.remove(p.size() - 1);

            }
        }

    }



        public static void getResult(List<List<Integer>> result, List<Integer> cur, int candidates[], int target, int start){

                for(int i = start; i < candidates.length && target >= candidates[i]; i++){
                    getResult(result,cur,candidates,target-candidates[i], i);
                    cur.add(candidates[i]);
                    getResult(result, cur, candidates, target - candidates[i], i);
                    cur.remove(cur.size() - 1);
                }//for
            //if
            if(target == 0 ){
                result.add(new ArrayList<Integer>(cur));
            }//else if
        }


    static void diceFace(String p, int target, int[] candidates) {
        if (target == 0) {
            System.out.println(p);
            return;
        }

        for (int i = 0; i < candidates.length &&  candidates[i] <= target; i++) {
            diceFace(p + candidates[i], target - candidates[i], candidates);
        }
    }
}