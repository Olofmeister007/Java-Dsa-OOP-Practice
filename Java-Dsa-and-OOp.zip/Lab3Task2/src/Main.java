import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner scn = new Scanner(System.in);
        Ticket t1 = new Ticket();
        System.out.println("Enter the number of Seat A , Seat B , Seat C tickets sold respectively");
        int n = scn.nextInt();
        int m = scn.nextInt();
        int l = scn.nextInt();
        t1.seattickets(n,m,l);
        System.out.println(t1.total());


    }
}

class Ticket {
    int seatA = 3000;
    int seatB = 2000;
    int seatC = 1000;
    int totalSales;



    void seattickets(int n , int m , int l)
    {
        seatA = n * seatA;
        seatB  = m * seatB;
        seatC = l * seatC;

    }
    int total ()
    {
        totalSales = seatA + seatB + seatC;

        return totalSales;
    }









}
