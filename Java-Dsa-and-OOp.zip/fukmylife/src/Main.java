import java.util.Stack;

public class Main {
    public static void main(String[] args) {

        String exp = "(a-2*(b+c)-d*e)*f";
        String exp2 = "(a-b/c)*(a/k-l)";
        String exp3 = "k+l-m*n+(o*p)*w/u/v*t+q";
        String exp4 = "231*+9-";
        String exp5 = "-+7*45+20";
        System.out.println(infixToPostFix(exp));
        System.out.println(infToPre(exp));
        System.out.println(infToPre(exp2));
        System.out.println(infToPre(exp3));
        System.out.println(postfixEvaluation(exp4));
        System.out.println(prefixEvaluation(exp5));

    }

    static int whatIs(char x)
    {
        if(x == '+' || x == '-' || x == '/' || x == '*')
            return 2;

        else if(x == '(' || x == ')' )
            return 3;

        else if (Character.isLetterOrDigit(x))
            return 1;

        return -1;
    }
    static int prec(char x)
    {
        if(x == '+' || x == '-')
            return 1;

        else if(x == '/' || x == '*')
            return 2;

        return -1;
    }
    static boolean postfixParantheses(String s)
    {
        Stack<Character> stack = new Stack<>();
        for(int i = 0 ; i < s.length() ; i++)
        {
            if(s.charAt(i) == '{' || s.charAt(i) == '(' || s.charAt(i) == '[')
            {
                stack.push(s.charAt(i));
            }

            else if(s.charAt(i) == '}')
            {
                if(stack.isEmpty() || stack.peek() != '{') return false;
                else  stack.pop();

            }
            else if(s.charAt(i) == ')')
            {
                if(stack.isEmpty() || stack.peek() != '(') return false;
                else stack.pop();

            }
            else if(s.charAt(i) == ']')
            {
                if(stack.isEmpty() || stack.peek() != '[') return false;
                else stack.pop();
            }

        }
        return stack.isEmpty();
    }

    static boolean prefeixParantheses(StringBuilder s)
    {
        Stack<Character> stack = new Stack<>();
        for(int i = 0 ; i < s.length() ; i++)
        {
            if(s.charAt(i) == '}' || s.charAt(i) == ')' || s.charAt(i) == ']')
            {
                stack.push(s.charAt(i));
            }

            else if(s.charAt(i) == '{')
            {
                if(stack.isEmpty() || stack.peek() != '}') return false;
                else stack.pop();
            }
            else if(s.charAt(i) == '(')
            {
                if(stack.isEmpty() || stack.peek() != ')') return false;
                else  stack.pop();
            }
            else if(s.charAt(i) == '[')
            {
                if(stack.isEmpty() || stack.peek() != ']') return false;
                else stack.pop();
            }

        }
        return stack.isEmpty();
    }

    static String infixToPostFix(String xd)
    {
        Stack<Character> xd1 = new Stack<>();
        StringBuilder result = new StringBuilder();

        if(postfixParantheses(xd)) {
            for (int i = 0; i < xd.length(); i++) {
                char c = xd.charAt(i);

                switch (whatIs(c)) {
                    case 1 -> result.append(c);

                    case 2 -> {
                        while (!xd1.isEmpty() && whatIs(xd1.peek()) == 2 && prec(c) <= prec(xd1.peek()))
                            result.append(xd1.pop());
                        xd1.push(c);
                    }
                    case 3 -> {
                        if (c == '(') xd1.push(c);

                         else if (c == ')') {
                            while (!xd1.isEmpty() && xd1.peek() != '(') {
                                result.append(xd1.pop());
                            }
                            if (!xd1.isEmpty()) {
                                xd1.pop();
                            }
                        }
                    }
                    default -> {
                        return "LOL NOOB";
                    }
                }

            }
            while (!xd1.isEmpty()) {
                result.append(xd1.pop());
            }

            return result.toString();
        }
        else
        {
            return "STOP RIGHT THERE THAT IS ILLEGAL";
        }
    }

    static String infToPre(String xd)
    {
        Stack<Character> xd1 = new Stack<>();
        StringBuilder result = new StringBuilder(xd);
        result.reverse();
        StringBuilder mew = new StringBuilder();


        if(prefeixParantheses(result)) {
            for (int i = 0; i < result.length(); i++) {
                char c = result.charAt(i);

                switch (whatIs(c)) {
                    case 1 -> mew.append(c);

                    case 2 -> {
                        while (!xd1.isEmpty() && whatIs(xd1.peek()) == 2 && prec(c) <= prec(xd1.peek()))
                            mew.append(xd1.pop());

                        xd1.push(c);
                    }
                    case 3 -> {
                        if (c == ')') {
                            xd1.push(c);
                        } else if (c == '(') {
                            while (!xd1.isEmpty() && xd1.peek() != ')') {
                                mew.append(xd1.pop());
                            }
                            if (!xd1.isEmpty()) {
                                xd1.pop();
                            }
                        }
                    }
                    default -> {
                        return "LOL NOOB";
                    }
                }

            }
            while (!xd1.isEmpty()) {
                mew.append(xd1.pop());
            }
            result = mew.reverse();

            return result.toString();
        }
        else
        {
            return "STOP RIGHT THERE THAT IS ILLEGAL";
        }
    }

    static int postfixEvaluation(String xd)
    {
        Stack<Integer> stack = new Stack<>();

        for(int i=0; i<xd.length(); i++)
        {
            char c=xd.charAt(i);

            if(Character.isDigit(c))
                stack.push(c - '0');

            else
            {
                int val1 = stack.pop();
                int val2 = stack.pop();

                switch (c) {
                    case '+' -> stack.push(val2 + val1);
                    case '-' -> stack.push(val2 - val1);
                    case '/' -> stack.push(val2 / val1);
                    case '*' -> stack.push(val2 * val1);
                }
            }
        }
        return stack.pop();

    }
    static int prefixEvaluation(String xd2)
    {
        Stack<Integer> stack=new Stack<>();
        StringBuilder xd = new StringBuilder(xd2);
        xd.reverse();

        for(int i=0;i<xd.length();i++)
        {
            char c=xd.charAt(i);

            if(Character.isDigit(c))
                stack.push(c - '0');

            else
            {
                int val2 = stack.pop();
                int val1 = stack.pop();

                switch (c) {
                    case '+' -> stack.push(val2 + val1);
                    case '-' -> stack.push(val2 - val1);
                    case '/' -> stack.push(val2 / val1);
                    case '*' -> stack.push(val2 * val1);
                }
            }
        }
        return stack.pop();
    }

    

}

