import java.awt.image.AreaAveragingScaleFilter;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        Graph graph = new Graph(5);
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);
        graph.addEdge(3, 4);
        List<Integer> neighbors = graph.getNeighbors(2);

        graph.bfs(0);
        System.out.println();
        graph.dfs(0);


    }
}

class Graph {

    int numNodes;
    int[][]  adjacencyMatrix;


    public Graph(int numNodes) {
        this.numNodes = numNodes;
        this.adjacencyMatrix = new int[numNodes][numNodes];

    }


    void addEdge(int n, int m)
    {
       adjacencyMatrix[n][m] = 1;
       adjacencyMatrix[m][n] = 1;

    }

    public List<Integer> getNeighbors(int node) {

        List<Integer> neighbors = new ArrayList<>();

        // Loop through the rows of the adjacency matrix
        for (int i = 0; i < numNodes; i++) {
            // If there is an edge from the given node to the current node, add it to the list of neighbors
            if (adjacencyMatrix[node][i] == 1) {
                neighbors.add(i);
            }
        }

        // Return the list of neighbors
        return neighbors;
    }

    void bfs(int n)
    {
        Queue<Integer> queue = new LinkedList<>();

        ArrayList<Integer> visited = new ArrayList<>();

        queue.add(n);
        visited.add(n);

        while(!queue.isEmpty())
        {
            int node = queue.poll();

            System.out.println(node);

            List<Integer> neighbours = getNeighbors(node);

            for(Integer neighbour : neighbours)
            {
                if(!visited.contains(neighbour))
                {
                    queue.add(neighbour);
                    visited.add(neighbour);
                }
            }

        }



    }

    void dfs(int n)
    {
        Stack<Integer> stack = new Stack<>();
        ArrayList<Integer> visited = new ArrayList<>();

        stack.add(n);
        visited.add(n);

        while(!stack.isEmpty())
        {
            int node = stack.pop();

            System.out.println(node);

            List<Integer> neighbours = getNeighbors(node);

            for(Integer neighbour : neighbours)
            {
                if(!visited.contains(neighbour))
                {
                    stack.add(neighbour);
                    visited.add(neighbour);
                }
            }

        }
        

    }


}