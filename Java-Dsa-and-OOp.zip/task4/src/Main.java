import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

         System.out.println("Enter Your Text");
        String userName = scn.nextLine();


        for(int i=0; i<userName.length();i++)
        {
            System.out.println(userName.charAt(i));
        }
    }
}