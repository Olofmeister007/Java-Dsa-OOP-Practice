public class Main {
    public static void main(String[] args){

        Student s1 = new Student();
        s1.setSubjectMarks(90,98,99);
        s1.showPercentage();
    }
}

class Student {
    float marks[] = new float[3];

    void setSubjectMarks(float suba, float subb,float subc)
    {
        marks[0] = suba;
        marks[1] = subb;
        marks[2] = subc;
    }

    void showPercentage()
    {
        float percentage = (marks[0]+marks[1]+marks[2])/3;
        System.out.println(percentage);
    }
}