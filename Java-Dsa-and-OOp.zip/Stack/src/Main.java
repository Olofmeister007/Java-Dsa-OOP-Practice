import java.util.LinkedList;

public class Main {

    LinkedList<Integer> ll = new LinkedList<>();





    public static void main(String[] args) {

    }


}