import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        int[] arr = {1,2,3,5,5};
        System.out.println(isArraySorted(arr, 0));
        System.out.println(findIndex(arr, 3,0));
        findAllIndex(arr,5,0);
        System.out.println(list);
        ArrayList<Integer> list = new ArrayList<>();
        System.out.println(findAllIndex2(arr,5,0, list));
        System.out.println(findAllIndex3(arr,5,0));

    }


    static boolean isArraySorted(int[] arr , int index)
    {
        if(index == arr.length - 1)
        {
            return true;
        }

        if(arr[index] <= arr[index + 1])
        {
            return isArraySorted(arr, index + 1);
        }
        return false;
    }

    static int findIndex(int[] arr , int target, int index)
    {
        if(index == arr.length)
        {
            return -1;
        }

        if(arr[index]  == target)
        {
            return index;
        }
        return findIndex(arr, target, index + 1);
    }

   static ArrayList<Integer> list = new ArrayList<>();


    static void findAllIndex(int[] arr , int target, int index)
    {
        if(index == arr.length)
        {
            return;
        }

        if(arr[index]  == target)
        {
            list.add(index);
        }
         findAllIndex(arr, target, index + 1);
    }

    static ArrayList<Integer> findAllIndex2(int[] arr , int target, int index, ArrayList<Integer> list)
    {
        if(index == arr.length)
        {
            return list;
        }

        if(arr[index]  == target)
        {
            list.add(index);
        }
        return findAllIndex2(arr, target, index + 1, list);
    }

    static ArrayList<Integer> findAllIndex3(int[] arr , int target, int index)
    {
        ArrayList<Integer> list = new ArrayList<>();
        if(index == arr.length)
        {
            return list;
        }

        if(arr[index]  == target)
        {
            list.add(index);
        }
        ArrayList<Integer> ans = findAllIndex3(arr, target, index + 1);

        list.addAll(ans);
        return list;
    }

}