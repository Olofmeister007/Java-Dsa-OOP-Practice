public class Main {
    public static void main(String[] args) {

        int[] xd1 = {1,3,4,2,2};
        int[] xd2 = {3,1,3,4,2};

        System.out.println(findDuplicate(xd1));

    }

    public static int findDuplicate(int[] nums) {
        int slow = 0;
        int fast = 0;

        do{
            slow = nums[slow];
            fast = nums[nums[fast]];
        }
        while(slow != fast);

        int temp = 0;

        while(temp != slow)
        {
            temp = nums[temp];
            slow = nums[slow];
        }

        return temp;

    }
}