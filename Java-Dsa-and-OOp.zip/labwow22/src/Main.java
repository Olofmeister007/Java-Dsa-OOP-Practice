import java.util.Scanner;

import java.util.Scanner;
import java.text.DecimalFormat;
public class Main {
    public static void main (String[] args)
    {
        double weight, height, bmi;

        Scanner input = new Scanner(System.in);
        input.useDelimiter(System.getProperty("line.separator"));

        System.out.println("Enter your weight(kg)");
        weight = input.nextDouble();
        System.out.println("Enter your height(cm)");
        height = input.nextDouble();

        DecimalFormat df = new DecimalFormat("0.0");

        bmi = (weight) / (Math.pow(height/100.0, 2));

        System.out.println("Your BMI(body mass index) is " + df.format(bmi));
        System.out.println();

        if (bmi >= 20 && bmi <=25) {
            System.out.println("Your BMI value is normal ");
        }
        else {
            System.out.println("Your BMI value is not normal ");

        }
    }

}
