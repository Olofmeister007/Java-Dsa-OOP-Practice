// ****************************************************************

// DogTest.java

//

// A simple test class that creates a Dog and makes it speak.

//

// ****************************************************************

public class Main

{

    public static void main(String[] args)

    {


        Labrador l = new Labrador("Zulfiqar","Blue");
        Yorkshire y = new Yorkshire("Meow");
        l.setBreedWeight(69);
        y.setBreedWeight(90);
        System.out.println(l.avgBreedWeight());
        System.out.println(y.avgBreedWeight());
        System.out.println(l.speak());
        System.out.println(y.speak());

    }


}
abstract class Dog

{

    protected final String name = "Spike";
    int BreedWeight;



    public Dog(String name) {
        name = name;
    }


    // ------------------------------------------------------------

    // Returns the dog's name

    // ------------------------------------------------------------

    public String getName()

    {

        return name;

    }

    // ------------------------------------------------------------

    // Returns a string with the dog's comments

    // ------------------------------------------------------------

    abstract public String speak();



}

// ****************************************************************

// Yorkshire.java

//

// A class derived from Dog that holds information about

// a Yorkshire terrier. Overrides Dog speak method.

//

// ****************************************************************
class Yorkshire extends Dog

{

    public Yorkshire(String name)

    {

        super(name);

    }

    // ------------------------------------------------------------

    // Small bark -- overrides speak method in Dog

    // ------------------------------------------------------------

    public String speak()

    {

        return "woof";

    }

    public void setBreedWeight(int n)
    {
        BreedWeight = n;
    }
    public  int avgBreedWeight()

    {

        return BreedWeight;

    }

}

// ****************************************************************

// Labrador.java

//

// A class derived from Dog that holds information about

// a labrador retriever. Overrides Dog speak method and includes

// information about avg weight for this breed.

//

// ****************************************************************

class Labrador extends Dog

{

    private String color; //black, yellow, or chocolate?



    public Labrador(String name, String color)

    {
        super(name);
        this.color = color;

    }

    // ------------------------------------------------------------

    // Big bark -- overrides speak method in Dog

    // ------------------------------------------------------------

    public String speak()

    {

        return "WOOF";

    }

    // ------------------------------------------------------------

    // Returns weight

    // ------------------------------------------------------------
    public void setBreedWeight(int n)
    {
        BreedWeight = n;
    }
    public  int avgBreedWeight()

    {

        return BreedWeight;

    }

}

