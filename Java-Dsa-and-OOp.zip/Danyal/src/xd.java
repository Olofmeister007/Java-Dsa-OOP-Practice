public class xd {
    static int a = 4;
    static int b;

    static {
        System.out.println("I am in a static block");
        b = a * 5;
    }
}
