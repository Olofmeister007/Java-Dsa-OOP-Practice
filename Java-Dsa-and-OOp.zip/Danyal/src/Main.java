public class Main {
    public static void main(String[] args) {
        Human danyal = new Human(22,"danyal",10000,false);
        Human kunal = new Human(22,"danyal",10000,false);
        Human mewo = new Human(22,"danyal",10000,false);

        System.out.println(Human.population);
    }
}