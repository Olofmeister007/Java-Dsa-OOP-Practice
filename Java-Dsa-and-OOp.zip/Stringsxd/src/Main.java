public class Main {
    public static void main(String[] args) {
        String a = new String("Danyal");
        String b = new String("Danyal");
        System.out.println(a==b);
        System.out.println(a.equals(b));

        String c = "Meow";
        String d = "Meow";
        System.out.println(c==d);

        float f = 0.5678943f;
        System.out.printf("The formatted values is %.2f" , f);
    }
}