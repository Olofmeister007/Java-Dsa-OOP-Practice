import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

       char[][] xd =  {
               {'5', '3', '.', '.', '7', '.', '.', '.', '.'},
               {'6', '.', '.', '1', '9', '5', '.', '.', '.'},
               {'.', '9', '8', '.', '.', '.', '.', '6', '.'},
               {'8', '.', '.', '.', '6', '.', '.', '.', '3'},
               {'4', '.', '.', '8', '.', '3', '.', '.', '1'},
               {'7', '.', '.', '.', '2', '.', '.', '.', '6'},
               {'.', '6', '.', '.', '.', '.', '2', '8', '.'},
               {'.', '.', '.', '4', '1', '9', '.', '.', '5'},
               {'.', '.', '.', '.', '8', '.', '.', '7', '9'}
       };

       solve(xd);

        display(xd);




    }



    public static boolean solve(char[][] board){
        for(int i = 0; i < board.length; i++){
            for(int j = 0; j < board[0].length; j++){
                if(board[i][j] == '.'){
                    for(char c = '1'; c <= '9'; c++){//trial. Try 1 through 9
                        if(isValid(board, i, j, c)){
                            board[i][j] = c; //Put c for this cell

                            if(solve(board))
                                return true; //If it's the solution return true
                            else
                                board[i][j] = '.'; //Otherwise go back
                        }
                    }

                    return false;
                }
            }
        }
        return true;
    }

    public static boolean isValid(char[][] board, int row, int col, char c){
        for (int i = 0; i < board.length; i++) {
            // check if the number is in the row
            if (board[row][i] == c) {
                return false;
            }
        }

        // check the col
        for (char[] nums : board) {
            // check if the number is in the col
            if (nums[col] == c) {
                return false;
            }
        }

        int sqrt = (int)(Math.sqrt(board.length));
        int rowStart = row - row % sqrt;
        int colStart = col - col % sqrt;

        for (int r = rowStart; r < rowStart + sqrt; r++) {
            for (int c1 = colStart; c1 < colStart + sqrt; c1++) {
                if (board[r][c1]== c )  {
                    return false;
                }
            }
        }
        return true;

    }

    public static void display(char[][] board)
    {
        for(char[] row : board)
        {
            for(char element : row)
            {
                System.out.print(element + " ");


            }
            System.out.println();
        }
    }
}
