import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Min xd = new Min();
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter the Three numbers");
        int a = scn.nextInt();
        int b = scn.nextInt();
        int c = scn.nextInt();
        xd.minNumber(a , b , c);
        

    }
}

class Min {

    void minNumber(int n , int m , int l)
    {
        if(n < m && n < l)
        {
            System.out.println(n + " is the smallest number ");
        } else if (m < n && m < l) {
            System.out.println(m + " is the smallest number ");
        }
        else if (l < n && l < m) {
            System.out.println(m + " is the smallest number ");
        }
        else if (n == m && n < l || n == l && n < m)
        {
            System.out.println(n + " is the smallest number");
        }
        else if (m == n && m < l || m == l && m < n)
        {
            System.out.println(m + " is the smallest number");
        }
        else if (l == m && l < n || l == n && l < m)
        {
            System.out.println(l + " is the smallest number");
        }
        else
        {
            System.out.println("There is no smallest number");
        }
    }

}