import java.util.Arrays;

class TugOfWar {
    // recursive function to find the minimum absolute difference between the sum of two subsets
    public static int findMinDiff(int[] arr, int n, int sum1, int sum2, int index) {
        // base case: if all elements have been considered
        if (index == n) {
            return Math.abs(sum1 - sum2);
        }

        // consider two possibilities for the current element:

        // either include it in the first subset or the second subset
        return Math.min(
                findMinDiff(arr, n, sum1 + arr[index], sum2, index + 1),
                findMinDiff(arr, n, sum1, sum2 + arr[index], index + 1)
        );

    }

    public static void main(String[] args) {
        int[] arr = {15,20,90,100};
        int n = arr.length;
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        int halfSum = sum / 2;

        // sort the array in ascending order
        Arrays.sort(arr);

        // find the minimum absolute difference between the sum of two subsets
        int minDiff = findMinDiff(arr, n, 0, 0, 0);

        System.out.println("Minimum absolute difference: " + minDiff);

    }
}
