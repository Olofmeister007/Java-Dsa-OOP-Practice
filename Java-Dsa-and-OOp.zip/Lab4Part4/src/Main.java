import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        Commision c = new Commision();
        System.out.println("Enter the number of hours worked");
        int a = scn.nextInt();
        System.out.println("Enter the number of Sales");
        double b = scn.nextDouble();
        c.caculateWage(b,a);

    }
}
class Commision {

    double hourlyWage = 7.25;


    void caculateWage(double n , int m)
    {
        double totalWage;
        if (n > 1.00 && n <= 99.99)
        {
            totalWage = (hourlyWage * m) + (n * 0.05);
            System.out.println("Your total wage is " + totalWage);
        }
        else if (n > 100 && n <= 299.99)
        {
            totalWage = (hourlyWage * m) + (n * 0.1);
            System.out.println("Your total wage is " + totalWage + "$");
        }
        else if (n > 300)
        {
            totalWage = (hourlyWage * m) + (n * 0.15);
            System.out.println("Your total wage is " + totalWage + "$");
        }
        else
        {
            totalWage = hourlyWage * m;
            System.out.println("Your Total wage is " + totalWage + "$");
        }
    }

}