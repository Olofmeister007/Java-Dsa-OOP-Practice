import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Character xd = 'a';
        String skip = "Bcccaad";
        String ans = "";

        String liso = "AppleMan";

//        skipChar(skip,ans);
        String wow = skipChar2(skip);
        System.out.println(wow);

        String wowo = skipApple(liso);
        System.out.println(wowo);

        System.out.println(skipApple("AppleMan"));
        System.out.println(skipAppNotApple("AppleMan"));




    }



    static void skipChar(String s , String ans)
    {

        if(s.isEmpty())
        {
            System.out.println(ans);
            return;
        }
        char c = s.charAt(0);
        if(c == 'a')
        {
            skipChar(s.substring(1),ans);
        }
        else {
            skipChar(s.substring(1), ans + c);

        }

    }

    static String skipChar2(String s)
    {

        if(s.isEmpty())
        {

            return "";
        }
        char c = s.charAt(0);
        if(c == 'a')
        {
            return skipChar2(s.substring(1));
        }
        else {
            return  c +  skipChar2(s.substring(1));

        }


    }


    static String skipApple(String s)
    {

        if(s.isEmpty())
        {

            return "";
        }
        char c = s.charAt(0);
        if(s.startsWith("Apple"))
        {
            return skipApple(s.substring(5));
        }
        else {
            return  c + skipApple(s.substring(1));

        }





    }

    static String skipAppNotApple(String s)
    {

        if(s.isEmpty())
        {

            return "";
        }
        char c = s.charAt(0);
        if(s.startsWith("App") && ! s.startsWith("Apple"))
        {
            return skipApple(s.substring(5));
        }
        else {
            return  c + skipApple(s.substring(1));

        }





    }
}