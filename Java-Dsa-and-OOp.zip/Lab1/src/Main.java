import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        JFrame window = new JFrame();
        window.setSize(600,300);
        window.setTitle("Lab 1 Java Program");
        window.setVisible(true);

    }
}