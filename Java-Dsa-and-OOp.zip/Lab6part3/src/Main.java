import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        int counter = 0;
        int[] question;
        System.out.println("How many questions are in the quiz?");
        int totalQ = input.nextInt();
        question = new int[totalQ];
        int i = 0;

        for (i = 0; i < question.length; i++) {
            System.out.println("Enter the correct answer of question no " + (i + 1));
            question[i] = input.nextInt();
        }

        do {

            for (int j = 0; j < question.length; j++) {
                System.out.println("Enter your answer for question no " + (j + 1));
                if (input.nextInt() == question[j]) {
                    counter += 1;
                }
            }
            DecimalFormat df = new DecimalFormat("0.00");

            double percentage = (double) counter / totalQ;

            System.out.println("Your marks: " + counter);
            System.out.println("Your percentage: " + df.format(percentage * 100));
            counter = 0;

            System.out.println("Enter(1) if you want to grade another quiz and anything else if you dont");
            i = input.nextInt();
            if (i < 1 || i > 2) {
                System.out.println("Error!");
                System.exit(0);
            }
        } while (i == 1);

    }
}
