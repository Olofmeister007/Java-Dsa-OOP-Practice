class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

 class stackLL {
    int top;
    Node head;
    Node tail;

    stackLL() {
        top = 0;
        head = null;
        tail = null;
    }

    public void push(int val) {
        Node temp = new Node(val);
        if (head == null) {

            head = temp;
            tail = temp;
            top = head.data;
        }

        else {
            temp.next = head;
            head = temp;
            top = head.data;

        }

    }

    public int pop() {
        int xd = top;
        head = head.next;
        top = head.data;
        return xd;
    }

    public int peek() {
        if (head == null) {
            isEmpty();
        }

        else {
            top = head.data;
        }
        return top;
    }

    public void printKar() {
        Node i;
        i = head;
        while (i != null) {

            System.out.print(i.data + "\n");
            i = i.next;
        }

    }

    public boolean isEmpty() {
        if (head == null) {
            return true;
        } else {
            return false;

        }

    }

    public static void main(String[] args) {
        stackLL l = new stackLL();
        l.push(67);
        l.push(89);
        l.push(34);

        l.pop();
        System.out.println(l.peek());
        l.printKar();
    }
}