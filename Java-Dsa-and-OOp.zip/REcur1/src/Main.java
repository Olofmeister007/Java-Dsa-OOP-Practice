import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] arr = {1 , 2 , 3 ,4 ,5 };
        recur(arr);

    }

   static void recur (int[] arr)
    {
        if(arr.length == 1)
        {
            return ;
        }
        int [] temp = new int[arr.length -1];
        for (int i= 0 ;i < temp.length ; i++ )
        {
            temp[i] = arr[i] + arr[ i + 1];
        }
        recur(temp);

        System.out.println(Arrays.toString(temp));
    }
}