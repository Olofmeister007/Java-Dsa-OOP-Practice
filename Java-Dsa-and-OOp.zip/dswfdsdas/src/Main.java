public class Main {
    public static void main(String[] args) {
        Integer a = 10;

        for(int i = 1; i< 3 ; i++)
        {
            a = a * i;
            System.out.println(a);
        }
        System.out.println(a);
    }
}