import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[] arr = { 5 , 4 , 3, 2, 1};
        selectionSort(arr);
        System.out.println(Arrays.toString(arr));
    }


    static void BubbleSort(int[] arr)
    {
        boolean swap;

        for(int i = 0 ; i < arr.length ; i++)
        {
            swap = false;
            for(int j = 1; j< arr.length - i ; j++)
            {
                if(arr[j] < arr[j-1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j-1];
                    arr[j-1] = temp;
                    swap = true;
                }

            }
            if(!swap)
            {
                break;
            }
        }
    }

    static void insertionSort(int[] arr)
    {
        for(int i = 0 ; i< arr.length -1  ; i++)
        {
            for(int j = i+1 ; j > 0 ; j--)
            {
                if(arr[j] < arr[j-1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j-1];
                    arr[j-1] = temp;
                }
                else {
                    break;
                }
            }
        }
    }
    static void selectionSort(int[] arr)
    {
        for(int i= 0 ; i< arr.length ; i++)
        {
            int min = i;
            for(int j = i+1 ; j < arr.length ; j++)
            {
                if(arr[min] > arr[j]){
                    min = j;
                }

            }
            int temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }
}


