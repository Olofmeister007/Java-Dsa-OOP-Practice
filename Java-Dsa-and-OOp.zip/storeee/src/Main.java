public class Main {
    public static void main(String[] args) {

    }
}

class Invoice {
    int number;
    double total;
    Customer customer;
    Store store;

    public Invoice(int number, double total, Customer customer, Store store) {
        this.number = number;
        this.total = total;
        this.customer = customer;
        this.store = store;
    }

    int getNumber()
    {
        return number;
    }
    int getStoreId()
    {
        return store.id;
    }
    int getNumberofItems(int items)
    {
        return items;
    }
    void addCustomer (Customer cust)
    {
        customer.id += cust.id;
        customer.gender += cust.gender;
        customer.name += cust.name;
    }
     void addInvoiceTotal(double total1)
     {
         total += total1;
     }
     double getInvoiceTotal()
     {
         return total;
     }

}

class Store {
    int id;
    String name;

    public Store(int id, String name) {
        this.id = id;
        this.name = name;
    }

    int getId()
    {
        return id;
    }
    String getName()
    {
        return name;
    }


}

class Customer {
    int id;
    String name;
    char gender;

    public Customer(int id, String name, char gender) {
        this.id = id;
        this.name = name;
        this.gender = gender;
    }
    String getName()
    {
        return name;
    }
    int getId()
    {
        return id;
    }
    char getGender()
    {
        return gender;
    }
}