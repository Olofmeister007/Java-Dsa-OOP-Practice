import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Points p1 = new Points();
        System.out.println("Enter the number of Points");
        Scanner scn = new Scanner(System.in);
        int points = scn.nextInt();
        p1.points(points);

    }

}

class Points {

    void points (int n)
    {
        if (n >= 100 && n < 200)
        {
            System.out.println("You won a free cup of coffee.");
        }
        else if (n >= 200 && n < 300)
        {
            System.out.println("You won a free cup of coffee and a regular-size doughnut");
        }
        else if (n >= 300 && n < 400)
        {
            System.out.println("You won a free cup of coffee and a regular-size doughnut and a 12-oz orange juice.");
        }
        else if (n >= 400 && n < 500)
        {
            System.out.println("You won a free cup of coffee and a regular-size doughnut and a 12-oz orange juice and a combo breakfast.");
        }
        else if (n >= 500)
        {
            System.out.println("You won a free cup of coffee and a regular-size doughnut and a 12-oz orange juice and a combo breakfast and a reserved table for one week.");
        }
        else
        {
            System.out.println("Invalid Input");
        }
    }
}