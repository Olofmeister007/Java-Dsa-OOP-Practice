import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int tperson;
        System.out.println("Enter the number of salesperson");
        tperson = scn.nextInt();
        Sales s1 = new Sales(tperson);
        s1.setSales();
        System.out.println(s1.max);
        System.out.println(s1.min);
        System.out.println(s1.total);
        System.out.println();
        s1.getSales();
        int value;
        System.out.println("Enter the value to compare sales with");
        value = scn.nextInt();
        s1.peoplewhoSuck(value);



    }
}

class Sales {
    private int [] sales;
    int person,total;
    int max = 0,counter = 0 ;
    int min = 0;

    Scanner scn = new Scanner(System.in);

    public Sales(int person) {
        this.person = person;
        sales = new int[person];

    }



    public void setSales() {
        for(int i=0 ; i< sales.length;i++)
        {
            System.out.println("Enter sales of salesperson " + (i+1));
            sales[i] = scn.nextInt();

            if(i == 0)
            {
                max = sales[i];
                min = sales[i];
            }
            if(sales[i] >= max)
            {
                max = sales[i];
            }
            else
            {
                min = sales[i];
            }
            total += sales[i];



        }

    }
    public void getSales() {
        for(int i =0 ; i< sales.length; i++)
            System.out.println("The sales of salesperson " + (i+1) + " is " + sales[i]);

    }

    public void peoplewhoSuck(int w)
    {
        for(int i = 0 ; i< sales.length; i++)
        {
            if(sales[i] > w)
            {
                System.out.println("The SalesPerson " + (i+1) + " exceeds the value with " + sales[i]);
                counter++;
            }


        }
        System.out.println("The number of people who exceed the amount is " + " is " + counter);
    }
}