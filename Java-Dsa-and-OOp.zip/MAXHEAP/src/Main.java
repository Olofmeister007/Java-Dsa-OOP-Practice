import java.util.NoSuchElementException;
public class Main {
    public static void  main(String[] args) {
        heap heap1 = new heap(5);
        heap1.insert(12);
        heap1.insert(1);
        heap1.insert(57);
        heap1.insert(3);
        heap1.insert(17);
        heap1.print();
        heap1.delete();
        System.out.println();
        heap1.print();
        System.out.println("Height of heap");
        System.out.println(heap1.height());

    }


}
 class heap {

    private int size;
    private int[] heap;

    public heap(int capacity)
    {
        heap = new int[capacity];
    }



    public void insert(int val)
    {
        heap[size] = val;
        size++;
        heapify(heap);

    }

    void heapify(int[] arr)
    {
        int currentIndex = size - 1;
        while(heap[currentIndex] > 0)
        {
            int parentIndex = (currentIndex - 1) / 2;
            if (heap[currentIndex] > heap[parentIndex])
            {
                swap(heap , currentIndex , parentIndex);
                currentIndex = parentIndex;
            }
            else {
                break;
            }
        }

    }

    static void swap(int[] arr , int a , int b)
    {
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }

    void print()
    {
        for (int j = 0 ; j < size ; j++) {
            System.out.println(heap[j]);
        }
    }

    public int delete()
    {
        if(size < 1)
        {
            throw new NoSuchElementException("Heap is Empty");
        }
        int root = heap[0];
        heap[0] = heap[size -1];
        size--;

        reHeapify(0);
        return root;
    }

    public void reHeapify(int index)
    {
        int leftChild = (index * 2) + 1;
        int rightChild = (index * 2) + 2;
        int largest = index;

        if(leftChild < size && heap[leftChild] > heap[largest])
        {
            largest = leftChild;
        }
        if(rightChild < size && heap[rightChild] > heap[largest])
        {
            largest = rightChild;
        }

        if(largest != index) {
            swap(heap, index, largest);
            reHeapify(largest);
        }
    }

        int height()
        {
           return height(heap);

        }
      int height(int[] heap) {
         // Calculate the number of nodes in the heap
         int n = heap.length;

         // Initialize the height to 0
         int h = 0;

         // Calculate the height of the heap using the formula:
         // height = floor(log2(n))
         while (n > 0) {
             h++;
             n >>= 1;
         }

         // Return the height
         return h;
     }



 }