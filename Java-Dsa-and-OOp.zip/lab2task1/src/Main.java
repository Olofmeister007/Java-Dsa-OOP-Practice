import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int ageOnEarth;
        int ageOnPlanet;
        int choice;
        int revolution = 0;
        String[] PlanetNames = {"Mercury","Venus","Jupiter"};
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Your age");
        ageOnEarth = input.nextInt();
        System.out.println("Enter 1 for Mercury");
        System.out.println("Enter 2 for Venus");
        System.out.println("Enter 3 for Jupiter");


        choice = input.nextInt();

        if(choice == 1)
        {
            revolution = 88;

        }
        else if(choice == 2)
        {
            revolution = 225;

        }
        else if(choice == 3)
        {
            revolution = 4380;

        }
        else {
            System.out.println("Enter a number between 1-3");
        }

        ageOnPlanet = (ageOnEarth * 365) / revolution;
        System.out.println("Your age on "+PlanetNames[choice-1]+" is "+ageOnPlanet);
    }
}