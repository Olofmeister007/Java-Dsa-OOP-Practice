public class Main {
    static int binary(int val){
        int[] arr={1,2,3,4};
        int start=0;
        int end=arr.length-1;
        while(start<=end){
            int mid=start+(end-start)/2;
            if(arr[mid]==val){
                return 1;
            }
            else if(arr[mid]>val){
                end = mid - 1;
            }
            else{
                start=mid + 1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {

        System.out.println(binary(5));
    }
}