import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        boolean[][] board = {
                {true, true, true,true},
                {true, true, true,true},
                {true, true, true,true}
        };
        int[][] path = new int[board.length][board[0].length];
//        allPathPrint("", board, 0, 0, path, 1);
//        allPath("", board, 0,0);
        char[][] xd = {{'A','B','C','E'},
                {'S','F','C','S'},
                {'A','D','E','E'}};
        boolean now = false;
        String word = "ABCB";
        for(int i = 0 ; i < xd.length ; i++)
        {
            for(int j = 0; j< xd[0].length ; j++)
            {
                if(xd[i][j] == word.charAt(0) )
                {
                    now = now || (wordSearch2(board,i,j,word,xd,0));
                }

            }

        }
        System.out.println(now);





    }

    static void allPath(String p, boolean[][] maze, int r, int c) {
        if (r == maze.length - 1 && c == maze[0].length - 1) {
            System.out.println(p);

            return;
        }

        if (!maze[r][c]) {
            return;
        }

        // i am considering this block in my path
        maze[r][c] = false;

        if (r < maze.length - 1) {
            allPath(p + 'D', maze, r+1, c);
        }

        if (c < maze[0].length - 1) {
            allPath(p + 'R', maze, r, c+1);
        }

        if (r > 0) {
            allPath(p + 'U', maze, r-1, c);
        }

        if (c > 0) {
            allPath(p + 'L', maze, r, c-1);
        }

        // this line is where the function will be over
        // so before the function gets removed, also remove the changes that were made by that function
        maze[r][c] = true;
    }



    static void allPathPrint(String p, boolean[][] maze, int r, int c, int[][] path, int step) {
        if (r == maze.length - 1 && c == maze[0].length - 1) {
            path[r][c] = step;
            for(int[] arr : path) {
                System.out.println(Arrays.toString(arr));
            }
            System.out.println(p);
            System.out.println();
            return;
        }

        if (!maze[r][c]) {
            return;
        }

        // i am considering this block in my path
        maze[r][c] = false;
        path[r][c] = step;
        if (r < maze.length - 1) {
            allPathPrint(p + 'D', maze, r+1, c, path, step+1);
        }

        if (c < maze[0].length - 1) {
            allPathPrint(p + 'R', maze, r, c+1, path, step+1);
        }

        if (r > 0) {
            allPathPrint(p + 'U', maze, r-1, c, path, step+1);
        }

        if (c > 0) {
            allPathPrint(p + 'L', maze, r, c-1, path, step+1);
        }

        // this line is where the function will be over
        // so before the function gets removed, also remove the changes that were made by that function
        maze[r][c] = true;
        path[r][c] = 0;
    }


    static boolean wordSearch(String p, boolean[][] maze, int r, int c,String word, char[][] board, int idx) {
        if (r< 0 || r == board.length || c < 0 || c == board[0].length || board[r][c] != word.charAt(idx)) {
            return false;
        }

        if(idx == word.length() - 1)
        {
            return true;
        }

        if (!maze[r][c]) {
            return false;
        }

        // i am considering this block in my path



        boolean found =  wordSearch(p + board[r][c], maze, r + 1, c, word, board, idx + 1) ||
                wordSearch(p + board[r][c], maze, r - 1, c, word, board, idx + 1) ||
                wordSearch(p + board[r][c], maze, r, c + 1, word, board, idx + 1) ||
                wordSearch(p + board[r][c], maze, r, c - 1, word, board, idx + 1);
        // this line is where the function will be over
        // so before the function gets removed, also remove the changes that were made by that function
        maze[r][c] = true;
        return found;
    }

    static boolean wordSearch2(boolean[][] maze, int r, int c,String word, char[][] board, int idx) {

        if(idx == word.length()  )
        {

            return true;
        }
        if (board[r][c] != word.charAt(idx)) {
            return false;
        }


        if (!maze[r][c]) {
            return false;
        }

        maze[r][c] = false;

        boolean found = false;
        // i am considering this block in my path
        if (r < maze.length - 1) {
            boolean one = wordSearch2(maze, r+1, c,word,board,idx+1);
            found = one || found;
        }

        if (c < maze[0].length - 1) {
            boolean two = wordSearch2( maze, r, c+1,word,board,idx+1);
            found = two || found;
        }

        if (r > 0) {
            boolean three = wordSearch2( maze, r-1, c,word,board,idx+1);
            found = three || found;
        }

        if (c > 0) {
            boolean four = wordSearch2( maze, r, c-1,word,board,idx+1);
            found = four || found;
        }



        // so before the function gets removed, also remove the changes that were made by that function
        maze[r][c] = true;
        return found;
    }



}