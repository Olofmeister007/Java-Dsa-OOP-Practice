import java.util.Stack;

public class Main {
    public static void main(String[] args) {

        String exp = "(a-2*(b+c)-d*e)*f";
        System.out.println(infixToPostFix(exp));

    }


    static int whatIs(char x)
    {
        if(x == '+' || x == '-' || x == '/' || x == '*')
            return 2;

        else if(x == '(' || x == ')' )
            return 3;

        else if (Character.isLetterOrDigit(x))
            return 1;

        return -1;
    }
    static int prec(char x)
    {
        if(x == '+' || x == '-')
            return 1;

        else if(x == '/' || x == '*')
            return 2;

        return -1;
    }

    static String infixToPostFix(String xd)
    {
        Stack<Character> xd1 = new Stack<>();
        StringBuilder result = new StringBuilder();


        for(int i=0 ; i<xd.length() ; i++)
        {
            char c = xd.charAt(i);

            switch (whatIs(c)) {
                case 1 ->
                    result.append(c);

                case 2 -> {
                    while (!xd1.isEmpty() && whatIs(xd1.peek()) == 2 && prec(c) <= prec(xd1.peek()))
                        result.append(xd1.pop());

                    xd1.push(c);
                }
                case 3 -> {
                    if (c == '(') {
                        xd1.push(c);
                    } else if (c == ')') {
                        while (!xd1.isEmpty() && xd1.peek() != '(') {
                            result.append(xd1.pop());
                        }
                        if (!xd1.isEmpty()) {
                            xd1.pop();
                        }
                    }
                }
                default -> {
                    while (!xd1.isEmpty()) {
                        result.append(xd1.pop());
                    }
                }
            }

        }

        return result.toString();
    }



}