public class Main {
    public static void main(String[] args) {
        heap heap1 = new heap(5);
        heap1.insert(12);
        heap1.insert(1);
        heap1.insert(57);
        heap1.insert(3);
        heap1.insert(17);
        heap1.print();
        heap1.delete();
        System.out.println();
        heap1.print();

    }
}

class heap {

    int[] heap;
    int size;

    public heap(int n) {
        this.heap = new int[n];
    }

    void insert (int val)
    {
        heap[size] = val;
        size++;
        heapify();
    }

    void heapify()
    {
        int currentIndex = size - 1;

        while(currentIndex > 0)
        {
            int ParentIndex = (currentIndex - 1) / 2;
            if(heap[currentIndex] > heap[ParentIndex])
            {
                int temp = heap[currentIndex];
                heap[currentIndex] = heap[ParentIndex];
                heap[ParentIndex] = temp;
                ParentIndex = currentIndex;
            }
            else {
                break;
            }


        }
    }

    void print()
    {
        for(int i= 0 ; i< size ; i++)
        {
            System.out.println(heap[i]);
        }
    }

    void delete()
    {
        int root = heap[0];
        heap[0] = heap[size - 1];
        size--;
        reHeapify(0);

    }

     void reHeapify(int index) {
        int leftChildIndex = (index * 2) + 1;
        int rightChildIndex = (index * 2) + 2;

        int largest = index;

        if(largest < size && heap[largest] < heap[leftChildIndex])
        {
            largest = leftChildIndex;
        }

         if(largest < size && heap[largest] < heap[rightChildIndex])
         {
             largest = rightChildIndex;
         }

         if(largest != index)
         {
             int temp = heap[index];
             heap[index] = heap[largest];
             heap[largest] = temp;
             reHeapify(largest);
         }

    }


}