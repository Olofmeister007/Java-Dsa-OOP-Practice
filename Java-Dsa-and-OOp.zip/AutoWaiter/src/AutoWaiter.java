
import java.util.Scanner;

public class AutoWaiter {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int n ;
        int p;
        int skip = 0;
        n = scn.nextInt();
        for(int i=1 ; i<=n ; i++)
        {
            p = scn.nextInt();

            System.out.println(LastPick(p,skip));
        }

    }

    static int LastPick(int p , int skip)
    {
        skip++;
        if(p == 1)
        {
            return 1;
        }
        else
        {
            return (((LastPick(p - 1, skip) + skip - 1) % p) + 1);
        }
    }


}