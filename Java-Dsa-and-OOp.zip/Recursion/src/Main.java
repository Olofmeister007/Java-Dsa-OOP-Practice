public class Main {
    public static void main(String[] args) {
//        for (int i = 0; i < 11; i++) {
//            System.out.println(fiboFormula(i));
//        }

        System.out.println(fiboFormula(50));
        System.out.println(fiboFormula(10));
        printn(5);
        System.out.println(fact(4));
        System.out.println(sumOfDigits(1342));
        System.out.println(proOfDigits(1342));
        System.out.println(reverseNum(12345, 0));
        System.out.println(reverseNum2(12345));
        int rem = 0;
        int n = 12321;
        rem = 12321 / 10000;
        System.out.println(rem);
        System.out.println(countZeros(1340051,0));
    }

    static int fiboFormula(int n){
        // just for demo, use long instead
        return (int) ((Math.pow(((1+Math.sqrt(5))/2),n)-Math.pow(((1-Math.sqrt(5))/2),n))/Math.sqrt(5));
    }

    static int fibo(int n) {
        // base condition
        if (n < 2) {
            return n;
        }
        return fibo(n-1) + fibo(n-2);
    }

    static void printn(int n)
    {
        if( n == 0)
        {
            return;
        }
        System.out.println(n);
        printn(n-1);
        System.out.println(n);

    }
    static int fact(int n)
    {
        if( n < 2)
        {
            return n;
        }

        return n * fact(n-1);

    }
    static int sum(int n)
    {
        if( n < 2)
        {
            return n;
        }

        return n * sum(n-1);

    }

    static int sumOfDigits(int n)
    {
        if(n == 0)
        {
            return n;
        }

        return n % 10 + sumOfDigits(n / 10);

    }
    static int proOfDigits(int n)
    {
        if(n == 0)
        {
            return 0;
        }
        if(n < 10)
        {
            return n;
        }

        return n % 10 * proOfDigits(n / 10);

    }

    int curDig = 0;
    static int reverseNum(int n, int c)
    {
        if(n < 10)
        {
            return c * 10 + n;
        }

        int rem = n % 10;
        c = c * 10 + rem;

        return reverseNum(n/10, c);

    }
    static int sum = 0;
    static void reverseNum1(int n)
    {
        if(n == 0)
        {
            return;
        }

        int rem = n % 10;
        sum = sum * 10 + rem;

         reverseNum1(n/10);

    }

    static int reverseNum2(int n)
    {

        int digits = (int) Math.log10(n) + 1;
        return helper(n, digits);

    }

    static int helper(int n, int digits)
    {
        if(n % 10 == n)
        {
            return n;
        }

          int rem = n % 10;

        return rem * (int)Math.pow(10, digits-1) + helper(n/10,digits -1);


    }
    static int countZeros(int n, int c)
    {
        if(n == 0)
        {
            return c;
        }

        if(n % 10 == 0) {
            return countZeros(n / 10, c+1);
        }
        else {

            return countZeros(n/ 10 , c);
        }

    }









}