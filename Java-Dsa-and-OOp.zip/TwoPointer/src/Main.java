import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        int[] xd = {2,7,11,15};
        int target = 9;

        HashMap<Integer,Integer> twosum = new HashMap<>();


    }


}