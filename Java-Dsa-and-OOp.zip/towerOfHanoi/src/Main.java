public class Main {
    public static void main(String[] args) {
        towerOfHanoi(3, 'A', 'B','C');
    }


    public static void towerOfHanoi(int n, char source, char help, char destination)
    {
        if(n == 1)
        {
            System.out.println(n + " from " + source + " to " + destination + " using " + help);
            return;
        }

        towerOfHanoi(n-1, source, destination, help);
        System.out.println(n + " From " + source + " to " + destination + " using " + help);
        towerOfHanoi(n-1, help,source, destination);




    }
}