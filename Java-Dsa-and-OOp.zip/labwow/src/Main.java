import java.util.Scanner;
public class Main {
    public static void main (String[] args)
    {
        int choice;
        int earthAge;
        int planetDays;
        int ageOtherPlanet;
        String planetName[] = {"Earth", "Mercury", "Venus", "Jupiter"};

        Scanner scanner = new Scanner(System.in);
        scanner.useDelimiter(System.getProperty("line.separator"));

        System.out.println("Enter (1) for earth, (2) for Mercury, (3) for Venus, (4) for Jupiter");
        choice = scanner.nextInt();
        System.out.println("Enter you age");
        earthAge = scanner.nextInt();

        if (choice == 1) {
            planetDays = 365;
        }
        else if (choice == 2) {
            planetDays = 88;
        }
        else if (choice == 3) {
            planetDays = 225;
        }
        else {
            planetDays = 4380;
        }

        ageOtherPlanet = (earthAge * 365) / (planetDays);

        System.out.println("Your age on planet " + planetName[choice - 1] + " is " + ageOtherPlanet);
    }
}
