public class LL1 {

    Node head;
    Node tail;

    int size;

    void insertFirst(int val)
    {
        Node temp = new Node(val);
        temp.next = head;
        head = temp;

        if(tail == null)
        {
            tail = head;
        }

        size++;

    }

    void insertAfter(int val , int val2)
    {
        try {
            Node temp = head;
            while (temp.value != val) {
                temp = temp.next;
            }

            Node newNode = new Node(val2, temp.next);
            temp.next = newNode;
            size++;
        }

        catch(NullPointerException e){
            System.out.println("Value Dont Exist ");
            return;

    }
    }

    void insertLast(int val)
    {
        Node temp = new Node(val);
        if(head == null)
        {
           head = temp;
           tail = temp;
        }
        else
        {
            tail.next = temp;
            tail = temp;
        }
        size++;

    }
    void insert(int val, int index)
    {

        if(index == 0)
        {
            insertFirst(val);
        }
        else if(index == size-1)
        {
            insertLast(val);
        }
        else {
            Node temp = head;

            for (int i = 1; i < index; i++) {
                temp = temp.next;
            }

            Node newnode = new Node(val, temp.next);
            temp.next = newnode;

            size++;
        }

    }

    void deletelast()
    {
        Node temp = head;

        if(head != null)
        {
            while(temp.next != tail)
            {
                temp = temp.next;
            }
            temp.next = null;
            tail = temp;
            size--;

        }
    }

    void middle()
    {
        Node slow = head;
        Node fast = head;

        while(fast != null && fast.next != null)
        {
            slow = slow.next;
            fast = fast.next.next;
        }
        System.out.println(slow.value);
    }
    void printReverse(Node head)
    {
        if (head == null) return;

        printReverse(head.next);

        System.out.print(head.value+" ");
    }

    void deleteval(int val)
    {
        Node temp = head;
        Node temp2 = head;

        while(temp.value != val)
        {
            temp2 = temp;
            temp = temp.next;
        }

        temp2.next = temp.next;
    }

    void delete(int index){
        Node temp = head;

        for(int i = 1 ; i< index ; i++)
        {
            temp = temp.next;
        }

        temp.next = temp.next.next;

        size--;

    }
    void delete1(int index){
        Node temp = head;

        for(int i = 1 ; i< index ; i++)
        {
            temp = temp.next;
        }

        Node temp2 = temp.next;
        temp.next = temp2.next;


        size--;

    }


    void deletefirst()
    {
        if(head !=null) {
            head = head.next;
            size--;
        }
    }

    void display()
    {
        Node temp = head;
        while(temp != null)
        {
            System.out.print(temp.value + " " );
            temp = temp.next;
        }
        System.out.println("--> END");

    }

    Node Reversell()
    {
        Node head = Reversell(this.head);
        return head;
    }
    Node Reversell(Node head)
    {
        if(head != null || head.next == null)
        {
            return head;

        }

        Node xd = Reversell(head.next);
        xd.next.next = head;
        head.next = null;
        return xd;
    }




    class Node {
        int value;
        Node next;

        public Node() {

            next = null;
        }

        public Node(int value) {
            this.value = value;
            this.next = null;
        }

        public Node(int value, Node next) {
            this.value = value;
            this.next = next;
        }
    }
    public static void main(String[] args) {

        LL1 ll = new LL1();

       ll.insertFirst(20);
       ll.insertFirst(30);
       ll.insertFirst(50);
        ll.insertLast(60);
        ll.insert(80,2);
//        ll.deletelast();
//        ll.deletefirst();
       ll.insertAfter(60,90);
       ll.display();
       ll.delete1(2);
        ll.display();
        ll.deleteval(60);
        ll.display();
//        ll.printReverse(ll.head);
//        System.out.println(ll.size);
//        ll.middle();
//        ll.insertLast(90);
//        ll.insertLast(80);
//        ll.insertLast(100);
//        ll.insertLast(200);
//        ll.insertLast(600);
//        ll.insertLast(800);
//        ll.display();
//        ll.middle();
//        ll.printReverse(ll.head);
//        ll.insertLast(24);
//        ll.display();
       
        ll.display();
    }
}