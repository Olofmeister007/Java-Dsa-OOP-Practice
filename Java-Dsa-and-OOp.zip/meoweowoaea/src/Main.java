public class Main {
    public static void main(String[] args) {

        BoxWeight b1 = new BoxWeight();
        System.out.println(b1.h);
    }
}