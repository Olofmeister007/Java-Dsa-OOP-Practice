public class BoxWeight extends Box{

    int weight;

    public  BoxWeight()
    {
        this.weight = 4;
    }
    public BoxWeight(int l, int w, int h, int weight) {
        super(l, w, h);
        this.weight = weight;
    }
}
