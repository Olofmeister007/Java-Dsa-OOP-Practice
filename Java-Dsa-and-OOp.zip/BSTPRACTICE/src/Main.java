import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        BST bst = new BST();
        /* BST tree example
              45
           /     \
          10      90
         /  \    /
        7   12  50   */
        //insert data into BST
        bst.insert(45);
        bst.insert(10);
        bst.insert(7);
        bst.insert(12);
        bst.insert(90);
        bst.insert(50);
        //print the BST
        System.out.println("The BST Created with input data(Left-root-right):");
        bst.inOrder();
        System.out.println("The Paths in the bst are");
        bst.path();

        System.out.println("The leaves are");
        bst.printLeafs(bst.root);

        System.out.println("Whether Tree is Valid or Not");
        bst.isValidBST(bst.root);

        //delete leaf node
        System.out.println("\nThe BST after Delete 12(leaf node):");
        bst.delete(12);
        bst.inOrder();
        //delete the node with one child
        System.out.println("\nThe BST after Delete 90 (node with 1 child):");
        bst.delete(90);
        bst.inOrder();

        //delete node with two children
        System.out.println("\nThe BST after Delete 45 (Node with two children):");
        bst.delete(45);
        bst.inOrder();
        //search a key in the BST
        boolean ret_val = bst.search (50);
        System.out.println("\nKey 50 found in BST:" + ret_val );
        ret_val = bst.search (12);
        System.out.println("\nKey 12 found in BST:" + ret_val );
        System.out.println(bst.height(bst.root));

    }
}


class BST {
    class Node{
        int Data;
        Node right;
        Node left;

        public Node() {

        }

        public Node(int data) {
            Data = data;
            this.right = null;
            this.left = null;
        }
    }

    Node root = new Node();

    public BST() {
        this.root = null;
    }


    public void insert(int val){
        root =  insert(root , val);
    }

    Node insert(Node root, int val){
        if(root == null)
        {
            root = new Node(val);
            return root;
        }

        if(val < root.Data)
        {
            root.left = insert(root.left, val);
        }
        else if(val > root.Data)
        {
            root.right = insert(root.right, val);
        }

        return root;
    }

    boolean search(int val){
        return search(root , val);
    }
    boolean search (Node root, int val)
    {
        if(root == null)
        {
            return false;
        }
        if(val < root.Data)
        {
           return search(root.left, val);
        }
        else if(val > root.Data)
        {
           return search(root.right, val);
        }
        else {
            return true;
        }

    }

    void inOrder(){
        inOrder(root);
    }

    void inOrder(Node root)
    {
        if(root == null){
            return;
        }

        inOrder(root.left);
        System.out.println(root.Data);
        inOrder(root.right);
    }

    void PostOrder(){
        PostOrder(root);
    }

    void PostOrder(Node root)
    {
        if(root == null){
            return;
        }

        inOrder(root.left);
        inOrder(root.right);
        System.out.println(root.Data);
    }

    void PreOrder(){
        PreOrder(root);
    }

    void PreOrder(Node root)
    {
        if(root == null){
            return;
        }

        System.out.println(root.Data);
        inOrder(root.left);
        inOrder(root.right);
    }

    void delete(int val){
        root =  delete(root , val);
    }

    Node delete(Node root, int val){
        if(root == null)
        {
            return root;
        }
        if(val < root.Data)
        {
            root.left = delete(root.left, val);
        }

        else if(val > root.Data)
        {
            root.right = delete(root.right, val);
        }
        else{
            if(root.left == null && root.right == null){
                return null;
            }
            else if(root.left == null){
                return  root.right;
            }
            else if(root.right == null){
                return  root.left;
            }
            else{
                int min = minValue(root.right);
                root.Data = min;
                root.right = delete(root.right, min);
            }
        }

        return root;
    }

    int minValue(Node root)
    {
        if(root.left != null)
        {
            root = root.left;
        }
        return root.Data;
    }

    public int height(Node root){
        if(root == null){
            return 0;
        }
        else {
            int left = height(root.left);
            int right = height(root.right);
            return Math.max(left, right) + 1;
        }
    }

    public void path()
    {
        ArrayList<Integer> xd = new ArrayList<>();
        path(root,xd);
    }

    public void path(Node root, ArrayList<Integer> xd){

        if(root == null){
            return;
        }
        xd.add(root.Data);
        if(root.left == null && root.right == null)
        {
            printPath(xd);
            System.out.println();
        }
        else {
            path(root.left,xd);
            path(root.right,xd);
        }
        xd.remove(xd.size() - 1);
    }

    void printPath(ArrayList<Integer> xd)
    {
        for(int i= 0 ; i< xd.size() ; i++)
        {
            System.out.print(xd.get(i)+ "--> ");
        }
    }

        public  Node inorderSuccessor(Node root, Node node) {

                if(node.right != null)
                {
                    node = node.right;
                    while(node.left != null)
                    {
                        node = node.left;
                    }
                    return node;
                }
                else {
                    Node succ = null;
                    while(root != null) {
                        if (node.Data < root.Data) {
                            succ = root;
                            root = root.left;
                        } else if (node.Data > root.Data) {

                            root = root.right;
                        } else {
                            break;
                        }

                    }
                    return succ;
                }

        }




    public  Node inorderPredecessor(Node root, Node node) {
       if(root.left != null){
           node = node.left;
           while(node.right != null)
           {
               node =  node.right;

           }
           return node;

       }
       else {
           Node pre = null;
           while(root != null) {
               if (node.Data > root.Data) {
                   pre = root;
                   root = root.right;
               } else if (node.Data < root.Data) {
                   root = root.left;
               } else {
                   break;
               }
           }
           return pre;
       }
    }

    public boolean areIdentical(Node root1 , Node root2)
    {
        if(root1 == null && root2 == null)
        {
            return true;
        }
        if(root1 == null || root2 == null)
        {
            return false;
        }
        return (root1.Data == root2.Data) && areIdentical(root1.left , root2.left) && areIdentical(root1.right , root2.right);
    }

    void printLeafs(Node root)
    {
        if(root == null)
        {
            return;
        }
        if(root.left == null && root.right == null)
        {
            System.out.println(root.Data);
        }
        else
        {
            printLeafs(root.right);
            printLeafs(root.left);
        }
    }
    public void isValidBST(Node root) {
        System.out.println(isValidBST(root, Long.MIN_VALUE, Long.MAX_VALUE));
    }

    public boolean isValidBST(Node root, long minVal, long maxVal) {
        if(root == null)
        {
            return true;
        }
        if(root.Data >= maxVal || root.Data <= minVal)
        {
            return false;
        }
        return isValidBST(root.left, minVal , root.Data) && isValidBST(root.right, root.Data, maxVal);
    }



}
