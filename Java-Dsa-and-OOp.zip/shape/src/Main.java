public class Main {
    public static void main(String[] args) {


        for(int i= 5 ; i> 0 ; i--)
        {
            for(int j= 5 ; j > 0 ; j--)
            {
                if(i > j)
                {
                    System.out.print(i);
                }
                else {
                    System.out.print(j);
                }
            }
            System.out.println();
        }
    }
}