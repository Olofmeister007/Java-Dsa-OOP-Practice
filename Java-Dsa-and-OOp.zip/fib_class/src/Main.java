public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        int n = 5;

        System.out.println(fib1(n));


    }


    public static int fib1(int n, int[] dp)
    {


        dp[0] = 0;
        dp[1] = 1;

        dp[n-1] = fib1(n-1, dp) + fib1(n-2, dp);

        return dp[]
    }
}