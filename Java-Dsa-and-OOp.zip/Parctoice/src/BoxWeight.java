public class BoxWeight extends Box{
    int weight;

    BoxWeight()
    {
        this.weight = 4;
    }

    void BoxWeight(int l , int h , int w,int weight) {
        super(l,w,h);
        this.weight = weight;
    }
}
