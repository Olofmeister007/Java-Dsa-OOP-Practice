import javax.swing.*;
import java.text.DecimalFormat;
import java.util.Scanner;



class Box {
   int l;
   int w;
   int h;

   void Box()
   {
       this.l = 2;
       this.h = 2;
       this.w = 2;
   }
   void Box(Box old)
   {
       this.l = old.l;
       this.w = old.w;
       this.h = old.h;
   }
   void Box(int l , int h , int w)
   {
       this.h = h;
       this.w = w;
       this.l = l;
   }

}


