import java.util.Arrays;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {

        xd("Meow");

//        Arrays.sort();

        char arr[] = { 'K', 'L', 'D', 'E', 'A', 'C', 'G', 'H' };
        System.out.print("Original Array: [");

        // print the array
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("]");

        // sort the array
        Arrays.sort(arr, 0, arr.length);
        System.out.print("Sorted Array: [");

        // print the array
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("]");
    }

    public static char[] xd(String s)
    {
        char ss[] = s.toCharArray();
        char[] xd = {'z','x','n','a'};


//        Collections.sort();

//        System.out.println(Arrays.toString(ss));

        Arrays.sort(ss,0, ss.length);
        Arrays.sort(xd);

        System.out.println(Arrays.toString(xd));

        System.out.println(Arrays.toString(ss));

        return ss;
    }
}