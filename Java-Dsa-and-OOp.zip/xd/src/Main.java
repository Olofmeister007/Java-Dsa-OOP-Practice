import java.util.*;

public class Main {
    public static void main(String[] args) {
        String s = "   fly me   to   the moon  ";
        String[] xd = s.split(" ");

        System.out.println(Arrays.toString(xd));

        String w = "pwwkew";

        System.out.println(lengthOfLongestSubstring(w));

        int[] n = {2, 1 ,5 ,1 , 3 ,2};
        int[] x = {1, 1 ,1 ,8 , 8 ,8};
       int[] A =  {-8, 2, 3, -6, 10};

        System.out.println(maximumSumSubarray(x, 3));

        System.out.println(printFirstNegativeInteger(A, A.length, 2));

       ;
    }

    public static int lengthOfLongestSubstring(String s) {
        HashSet<Character> map = new HashSet<>();

        int l = 0;

        int maxl = 0;

        for(int r = 0 ; r  < s.length() ; r++)
        {
            while(map.contains(s.charAt(r)))
            {
                map.remove(s.charAt(l));
                l++;

            }
                map.add(s.charAt(r));
                maxl = Math.max(maxl, r - l + 1);


        }
        return maxl;
    }

    public static int maximumSumSubarray(int[] n, int k) {

        int l = 0;
        int r = 0;
        int max = 0;
        int sum = 0;

        while(r < n.length)
        {
            sum += n[r];

            if(r - l + 1 > k)
            {
               sum = sum - n[l];
               l++;
            }
            max = Math.max(max, sum);
            r++;
        }
        return max;

    }


    public static ArrayList<Integer> printFirstNegativeInteger(int A[], int N, int k)
    {
        ArrayList<Integer> ans = new ArrayList<>();
        Queue<Integer> neg = new LinkedList<>();

        int l = 0;
        int r = 0;

        while(r < N)
        {
            if(A[r] < 0)
            {
                neg.add(A[r]);
            }

            if(r - l + 1 == k)
            {
                if(neg.isEmpty())
                {
                    ans.add(0);
                }

                if(!neg.isEmpty() )
                {
                    ans.add(neg.peek());
                    if(!neg.isEmpty() && A[l] == neg.peek()) {
                        neg.poll();

                    }
                }
                l++;
            }
            r++;

        }

        return ans;
    }


}