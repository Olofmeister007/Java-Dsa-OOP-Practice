

public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 6,7 ,69,420 };
        int target = 420;
        System.out.println(zulfi(arr, target, 0, arr.length - 1));
    }

    static int zulfi(int[] arr, int target, int start, int end) {
        if (start > end) {
            return -1;
        }
        int m = start + (end - start) / 2;
        if (arr[m] == target) {
            return m;
        }
        if (target < arr[m]) {
            return zulfi(arr, target, start, m - 1);
        }
        return zulfi(arr, target, m + 1, end);
    }
}