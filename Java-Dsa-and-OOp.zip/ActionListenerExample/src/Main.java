import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*Declaring Event Handler class and implementing
ActionListener interface
*/
public class ActionListenerExample implements ActionListener {


    int count=0; //declaring and initializing counter variable


    //Creating objects of all the components
    JFrame frame = new JFrame("Action Listener");
    JButton redButton= new JButton("Red");
    JButton greenButton=new JButton("Green");
    JButton blueButton=new JButton("Blue");
    JLabel label= new JLabel();

    //Creating constructor of the class
    ActionListenerExample(){

        //Setting properties of JFrame
        frame.setSize(500,500);
        frame.getContentPane().setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Setting properties of RedButton
        redButton.setBounds(60,300,100,40);
        redButton.setFocusable(false);
        redButton.setFont(new Font("Arial",Font.BOLD,20));
        frame.add(redButton);

        //Setting properties of GreenButton
        greenButton.setBounds(190,300,100,40);
        greenButton.setFocusable(false);
        greenButton.setFont(new Font("Arial",Font.BOLD,20));
        frame.add(greenButton);

        //Setting properties of BlueButton
        blueButton.setBounds(320,300,100,40);
        blueButton.setFocusable(false);
        blueButton.setFont(new Font("Arial",Font.BOLD,20));
        frame.add(blueButton);

        //Setting properties of Label
        label.setBounds(170,350,200,40);
        label.setFont(new Font("Arial",Font.BOLD,20));
        frame.add(label);


        //Registering listener for components
        redButton.addActionListener(this);
        greenButton.addActionListener(this);
        blueButton.addActionListener(this);
    }

    //Overriding actionPerformed() method
    @Override
    public void actionPerformed(ActionEvent e) {

        //Incrementing counter when the user clicks on any Button
        count++;

        //Code for Red Button
        if(e.getSource()==redButton){

            //changing the background color of JFrame to Red
            frame.getContentPane().setBackground(Color.red);

            //Setting the label text with number of times the button clicked
            label.setText("No of clicks "+count);
        }

        //Code for Green Button
        else if(e.getSource()==greenButton){

            //changing the background color of JFrame to Green
            frame.getContentPane().setBackground(Color.green);

            //Setting the label text with number of times the button clicked
            label.setText("No of clicks "+count);
        }

        //Code for Blue Button
        else if(e.getSource()==blueButton){

            //changing the background color of JFrame to Blue
            frame.getContentPane().setBackground(Color.blue);

            //Setting the label text with number of times the button clicked
            label.setText("No of clicks "+count);
        }

    }

    //main method of our program
    public static void main(String[] args){

        //Creating object of the class
        ActionListenerExample listenerExample=new ActionListenerExample();
    }
}