import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String name = "Danyal";

        System.out.println(Arrays.toString(name.toCharArray()));


        int xd = 69420;
        System.out.println((int)Math.log10(xd)+1);

    }
}