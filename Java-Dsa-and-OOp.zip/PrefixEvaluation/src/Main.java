// Java program to evaluate value of a postfix expression

import java.util.Stack;

public class Main
{
    // Method to evaluate value of a postfix expression
    static int evaluatePostfix(String exp)
    {
        //create a stack
        Stack<Integer> stack=new Stack<>();
        StringBuilder xd = new StringBuilder(exp);
        xd = xd.reverse();

        // Scan all characters one by one
        for(int i=0;i<xd.length();i++)
        {
            char c=xd.charAt(i);

            // If the scanned character is an operand (number here),
            // push it to the stack.
            if(Character.isDigit(c))
                stack.push(c - '0');

                // If the scanned character is an operator, pop two
                // elements from stack apply the operator
            else
            {
                int val2 = stack.pop();
                int val1 = stack.pop();

                switch(c)
                {
                    case '+':
                        stack.push(val2+val1);
                        break;

                    case '-':
                        stack.push(val2- val1);
                        break;

                    case '/':
                        stack.push(val2/val1);
                        break;

                    case '*':
                        stack.push(val2*val1);
                        break;
                }
            }
        }
        return stack.pop();
    }

    // Driver program to test above functions
    public static void main(String[] args)
    {
        String exp="-+7*45+20";
        System.out.println("Prefix Evaluation: "+evaluatePostfix(exp));
    }
}

