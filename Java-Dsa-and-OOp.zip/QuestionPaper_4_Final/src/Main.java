import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
      CricketTeam c1 = new CricketTeam();
      c1.setOrder();
      c1.replace(2);


    }


}
class Player {
     String name;
    private int playingOrder;
    private int ranking;

    public Player(String name, int playingOrder, int ranking) {
        this.name = name;
        this.playingOrder = playingOrder;
        this.ranking = ranking;
    }
}
class CricketTeam {

    private Player[] team = new Player[12];
    Player[] copy = new Player[team.length - 1];




    public void setOrder()
    {
        Scanner scn = new Scanner(System.in);
        String name;
        int PlayingOrder;
        int ranking;
        for(int i = 0; i<12; i++) {
            System.out.println("Enter the player name");
            name = scn.next();
            System.out.println("Enter the player PlayingOrder");
            PlayingOrder = scn.nextInt();
            System.out.println("Enter the player ranking");
            ranking = scn.nextInt();
            Player z = new Player(name, PlayingOrder, ranking);
            team[PlayingOrder-1]= z;
        }

    }
    public void replace(int index)
    {

        team[index] = team[11];

        for (int i = 0, j = 0; i < team.length; i++) {
            if (i != 11) {
                copy[j++] = team[i];
            }
        }
        System.out.println(copy[10].name);

    }


}







