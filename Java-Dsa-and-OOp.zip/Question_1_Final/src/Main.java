import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Items \n 1)Pakore \n 2)Sambose \n 3)Biryani \n What do you want to eat ? \n");
    MealCard m = new MealCard();
    m.addPoints(50);
    String item;
    item = scn.next();
    m.buyFood(item);
    System.out.println(m.points);


       

    }
}

class MealCard{

    int points;

    public MealCard() {
        this.points = 100;
    }
    public MealCard(int points) {
        this.points = points;
    }

    void addPoints(int m)
    {
        points += m;
    }

    void buyFood(String item)
    {

        if(item.equals("Pakore") )
        {
            points -= 50;
        }
        else if(item.equals("Sambose"))
        {
            points -= 20;
        }
        else if(item.equals("Biryani") )
        {
            points -= 90;
        }
        else
        {
            System.out.println("Not Available");
        }
        if(points <= 0)
        {
            System.out.println("you are Broke ");
        }
    }




}




