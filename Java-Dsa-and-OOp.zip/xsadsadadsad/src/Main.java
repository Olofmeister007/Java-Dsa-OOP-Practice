public class Main {
    public static void main(String[] args) {
        int maxCustomers = 0;

// loop through all customers
        for (int i = 1; i <= 6; i++) {
            // calculate the number of dates required for this customer
            int dates = 1 * i + 1 * (6 - i);

            // check if we have enough dates in stock to serve this customer
            if (dates <= 4) {
                // update the maximum number of customers that can be served
                maxCustomers = Math.max(maxCustomers, i);
            }
        }

// print the maximum number of customers that can be served
        System.out.println("Maximum number of customers that can be served: " + maxCustomers);

    }

}

