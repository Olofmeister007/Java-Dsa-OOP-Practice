import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

        Author author1 = new Author("Danyal","Danyalraxa007@gmail.com","male");

        Book book1 = new Book("Danyal",author1,25.99,69);


        System.out.println(book1.getAuthor());


    }
}
class Book {
    private String name;


    Author author;
    ;
    private double price;
    private int qtyInStock;

    public Book(String name, Author author, double price, int qtyInStock) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.qtyInStock = qtyInStock;
    }

    String getName()
    {
        return name;
    }
    String getAuthor()
    {
        return author.getName();

    }
    double getPrice()
    {
        return price;
    }
    int getQtyinStock()
    {
        return qtyInStock;
    }

    void setPrice(double price1)
    {
        price = price1;

    }

    void setQtyinstock(int qtyInstock2)
    {
        qtyInStock = qtyInstock2;
    }


}
class Author {
    String name;
    String email;
    String gender;

    public Author(String name, String email, String gender) {
        this.name = name;
        this.email = email;
        this.gender = gender;


    }
    public Author()
    {

    }

   String getName()
   {
       return name;
   }


}

