import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        int n = 5;
        int k = 5;
        int[] arr = {1, 1, 2, 2, 1};

        System.out.println(counts(n,k,arr));



    }

    public static Boolean counts(int n , int k, int [] values)
    {
        Map<Integer, Integer> ans = new HashMap<>();

        if( 2 * k  < n)
        {
            return  false;
        }

        for(int i = 0; i < values.length ; i++)
        {
            if(ans.containsKey(values[i]))
            {
                ans.put(values[i], ans.get(values[i]) + 1);
                if(ans.get(values[i]) > 2)
                {
                    return false;
                }
            }
            else {
                ans.put(values[i], 1);
            }


        }
        for (Map.Entry<Integer, Integer> entry : ans.entrySet())
        {
            System.out.println(entry.getKey() + " occurs " + entry.getValue()+" times ");
        }
        return true;
}


    }
