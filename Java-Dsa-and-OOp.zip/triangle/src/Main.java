public class Main {
    public static void main(String[] args) {
        triangle(4,0);

        System.out.println(upperChar("danyal",0));

    }

    static void triangle(int r , int c)
    {
        if(r == 0)
        {
            return;
        }
        if(c < r)
        {
            triangle(r , c+1);
            System.out.print("* ");
        }
        else
        {
            triangle(r-1 , 0);
            System.out.println();
        }
    }

    static char upperChar(String s, int i)
    {
        if(s.charAt(i)=='\0'){
            return 0;
        }
        if(Character.isUpperCase(s.charAt(i))) {
            return s.charAt(i);
        }
        try
        {
            return upperChar(s,i+1);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }

        return 0;



    }

}