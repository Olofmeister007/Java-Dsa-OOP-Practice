import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> str = new ArrayList<>();
    }

    public static String encode(List<String> strs) {
        // write your code here
    }

    /*
     * @param str: A string
     * @return: decodes a single string to a list of strings
     */
    public static List<String> decode(String str) {
        // write your code here
    }
}


