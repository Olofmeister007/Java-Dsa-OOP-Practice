import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        
    }





