import java.util.Arrays;
import java.util.NoSuchElementException;

public class Main {
    public static void main(String[] args) {
        MaxHeap heap1 = new MaxHeap(10);

       for(int i= 10 ; i > 0 ; i--)
       {
           heap1.insert(i);
       }

        heap1.printArray();

        heap1.delete();
        System.out.println();
        heap1.printArray();


    }
}



 class MaxHeap {
    // The array that stores the elements of the heap
    private int[] heap;
    // The number of elements in the heap
    private int size;

    public MaxHeap(int capacity) {
        heap = new int[capacity];
    }

    public void insert(int value) {
        // Add the new element to the end of the heap
        heap[size] = value;
        size++;

        // Heapify the heap by sifting the new element up
        int currentIndex = size - 1;
        while (currentIndex > 0) {
            int parentIndex = (currentIndex - 1) / 2;
            if (heap[currentIndex] > heap[parentIndex]) {
                // Swap the current element with its parent
                int temp = heap[currentIndex];
                heap[currentIndex] = heap[parentIndex];
                heap[parentIndex] = temp;
                currentIndex = parentIndex;
            } else {
                // The heap is valid
                break;
            }
        }
    }

     public int delete() {
         if (size < 1) {
             throw new NoSuchElementException("Heap is empty");
         }

         int max = heap[0];
         heap[0] = heap[size - 1];
         size--;
         percolateDown(0);
         return max;
     }

     private void percolateDown(int index) {
         int leftChild = 2 * index + 1;
         int rightChild = 2 * index + 2;
         int largest = index;

         // Find the largest element among the current element, its left child, and its right child
         if (leftChild < size && heap[leftChild] > heap[largest]) {
             largest = leftChild;
         }
         if (rightChild < size && heap[rightChild] > heap[largest]) {
             largest = rightChild;
         }

         // If the largest element is not the current element, swap them and continue percolating down
         if (largest != index) {
             swap(heap, index, largest);
             percolateDown(largest);
         }
     }
     private void swap(int[] array, int i, int j) {
         int temp = array[i];
         array[i] = array[j];
         array[j] = temp;
     }

     public void printArray()
    {
        for(int i= 0 ; i < size; i++)
        {
            System.out.println(heap[i]);
        }
    }

}