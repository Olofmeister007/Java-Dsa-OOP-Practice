public class Main {
    public static void main(String[] args) {
        int[][] nums = {
                {1,3,5,7},
                {10,11,16,20},
                {23,30,34,60}

                         };
        int target = 3;
        System.out.println(searchMatrix(nums, target));

    }
    public static boolean searchMatrix(int[][] matrix, int target) {
        int ind = potentialRow(matrix, target);
        if(ind != -1)
        {
            return searchInRow(matrix, ind , target);
        }
        return false;
    }

    public static int potentialRow(int[][] matrix, int target)
    {
        int low = 0;
        int high = matrix.length - 1;
        int colLast = matrix[0].length - 1;



        while(low <= high)
        {
            int mid = low + (high - low) / 2 ;
            if(target >= matrix[mid][0]  && target <= matrix[mid][colLast])
            {
                return mid;
            }
            else if(matrix[mid][0] < target)
            {
                low++;
            }
            else if(matrix[mid][0] > target)
            {
                high--;
            }

        }
        return -1;
    }

    public static boolean searchInRow(int[][] matrix, int row , int target)
    {
        int row1 = row;
        int column = matrix[row].length - 1;

        while(row1 <= column)
        {
            int mid = row1 + (column - row1) / 2;

            if(matrix[row1][mid] == target)
            {
                return true;
            }
            else if(matrix[row1][mid] < target)
            {
                column = mid + 1;
            }
            else
            {
                column = mid - 1;
            }

        }
        return false;
    }
}