import java.util.Stack;

public class Main {

    static boolean part(String s)
    {
        Stack<Character> xd = new Stack<>();
        for(int i=0 ; i<s.length() ; i++)
        {
            if(s.charAt(i) == '{')
            {
                xd.push('}');
            }
            else if(s.charAt(i) == '(')
            {
                xd.push(')');
            }
            else if(s.charAt(i) == '[')
            {
                xd.push(']');
            }
            else if(!xd.isEmpty() && xd.peek() == s.charAt(i))
            {
                xd.pop();
            }

        }
        return xd.isEmpty();
    }


    static int prec(char xd)
    {
        if(xd == '+' || xd == '-')
        {
            return 69;
        }
        else if(xd == '*' || xd=='/')
        {
            return 420;
        }
        return -1;
    }
    static boolean isOp(char op)
    {
        return (op == '+' || op == '-' || op == '*' || op == '/');
    }

    static String infToPs(String exp)
    {
        Stack<Character> wow = new Stack<>();
        StringBuilder result = new StringBuilder("");
            if(part(exp)) {
                for (int i = 0; i < exp.length(); i++) {
                    char c = exp.charAt(i);

                    if (Character.isLetterOrDigit(c)) {
                        result.append(c);
                    } else if (c == '(') {
                        wow.push(c);
                    } else if (c == ')') {
                        while (wow.peek() != '(') {
                            result.append(wow.pop());
                        }
                        wow.pop();
                    } else {
                        while (!wow.isEmpty() && isOp(wow.peek()) && prec(c) <= prec(wow.peek())) {
                            result.append(wow.pop());
                        }

                        wow.push(c);
                    }

                }

                while (!wow.isEmpty()) {
                    result.append(wow.pop());
                }

                return result.toString();
            }
            else
            {
                return "Parentheses Checker Failed";
            }

    }
    public static void main(String[] args) {
        String exp = "(a-2*(b+c)-d*e)*f";
        System.out.println(infToPs(exp));

    }

}