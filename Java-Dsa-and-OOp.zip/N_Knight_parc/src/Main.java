public class Main {
    public static void main(String[] args) {

        boolean[][] board = new boolean[4][3];

        System.out.println(Knights(board,0,6));


    }

    static int Knights(boolean[][] board, int row, int knights) {
        if (knights == 0) {
            display(board);
            System.out.println();
            return 1;
        }

        int count = 0;

        // placing the queen and checking for every row and col
        for (int col = 0; col < board.length; col++) {
            // place the queen if it is safe
            if(isValid(board, row, col)) {
                if (isSafe(board, row, col)) {
                    board[row][col] = true;
                    count += Knights(board, row + 1, knights - 1);
                    board[row][col] = false;
                }
            }
        }

        return count;
    }

    private static boolean isSafe(boolean[][] board, int row, int col) {
        // Check if the position (row, col) is inside the board bounds
        if (isValid(board, row - 1, col - 2) && board[row - 1][col - 2]) {
            return false;
        }

        if (isValid(board, row - 2, col - 1) && board[row - 2][col - 1]) {
            return false;
        }

        if (isValid(board, row - 2, col + 1) && board[row - 2][col + 1]) {
            return false;
        }

        if (isValid(board, row - 1, col + 2) && board[row - 1][col + 2]) {
            return false;
        }

        return true;
    }

    static boolean isValid(boolean[][] board, int r, int c) {
        int rows = board.length;
        int cols = board[0].length;

        if (r >= 0 && r < rows && c >= 0 && c < cols) {
            return true;
        }

        return false;
    }

    private static void display(boolean[][] board) {
        for(boolean[] row : board) {
            for(boolean element : row) {
                if (element) {
                    System.out.print("K ");
                } else {
                    System.out.print("_ ");
                }
            }
            System.out.println();
        }
    }


}