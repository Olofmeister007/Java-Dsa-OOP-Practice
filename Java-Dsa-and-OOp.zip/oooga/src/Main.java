import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Integer> arr = new ArrayList<>();

    }


    public static int recursion(int n)
    {
        System.out.println(n);
        return (recursion(n+1));

    }
}